/*
 * Email.java
 *
 * Created on 15. oktober 2007, 08:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.mortena.mail;

import com.asap.catalog.dao.Component;
import com.asap.configuration.ConfigurationManager;
import com.asap.util.HTMLMailSender;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import java.io.File;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import freemarker.template.Configuration;
import java.util.Locale;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author mortenandersen
 */
@Entity
@Table(name="System_Email")
public class Email extends Component implements java.io.Serializable{
    
    private static String dirPath;
    
    private String templatePath;
    private String subject;
    @Column (name="sendTo")
    private String to;
    @Column (name="sendFrom")
    private String from;
    
    @Transient
    private Map properties;
    public static final String TEMPLATEPATH = "/WEB-INF/view/mail/template/";
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;
    
    String templateName;
    
    public String getType(){
        return this.getClass().getName().substring(this.getClass().getPackage().getName().length()+1);
    }
    
    private String getPath(){
        return getDirPath()+getTemplatePath();
    }
    
    public void setProperty(String key, Object value){
        if (properties == null){
            properties = new HashMap();
        }
        properties.put(key,value);
    }
        
    /** Creates a new instance of Email */
    public Email() {
    }

    public String getTemplatePath() {
        if (templatePath == null && templateName == null){
            return TEMPLATEPATH+this.getType()+".ftl";
        }
        else if ( templateName != null){
            return TEMPLATEPATH+getTemplateName()+".ftl";
        }
        return templatePath;
    }

    public void setTemplatePath(String templatePath) {
        this.templatePath = templatePath;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public Map getProperties() {
        return properties;
    }
    
    private String getConfiguredSubject(){
        return ConfigurationManager.getParameter(getType()+".subject");        
    }
    
    
    public void send(){
        HTMLMailSender sender = new HTMLMailSender();
        try {           
            sender.setToAddress(getTo());     
            if (getFrom()==null){
                String specificFrom = ConfigurationManager.getParameter(this.getType()+".mail.from");
                if (specificFrom == null){
                    sender.setFromAddress(ConfigurationManager.getParameter("mail.from"));
                }
                else{
                    sender.setFromAddress(specificFrom);
                }
            }
            else{
                sender.setFromAddress(getFrom());
            }
            if ( getSubject() == null ){
                sender.setSubject(getConfiguredSubject());   
            }
            else{
                sender.setSubject(subject);
            }
                     
           // resolve result of Template
            Writer writer = new StringWriter();
            Configuration cfg = new Configuration();
            cfg.setDirectoryForTemplateLoading( new File( getDirPath() ) );
            cfg.setObjectWrapper(new DefaultObjectWrapper()); 
            System.out.println("templatepath = "+getTemplatePath());
            Template template = cfg.getTemplate(getTemplatePath());
            cfg.setEncoding(new Locale("da_DK"),"utf-8");
            String val = template.getOutputEncoding();
            template.setEncoding("Cp1252");
            template.setOutputEncoding("Cp1252");            
            template.process(getProperties(), writer);
            String messageText = writer.toString();
            messageText = HTMLMailSender.replaceDanishLetters(messageText);
            sender.setMessageText(messageText);
            sender.sendMail();           
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public static String getDirPath() {
        return dirPath;
    }

    public static void setDirPath(String aDirPath) {
        dirPath = aDirPath;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public

    String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }


    
}
