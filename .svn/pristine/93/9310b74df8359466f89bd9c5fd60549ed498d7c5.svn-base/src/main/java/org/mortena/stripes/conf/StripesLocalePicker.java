package org.mortena.stripes.conf;

import com.asap.catalog.dao.Page;
import com.asap.catalog.enums.Language;
import net.sourceforge.stripes.localization.LocalePicker;
import net.sourceforge.stripes.localization.DefaultLocalePicker;
import net.sourceforge.stripes.config.Configuration;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-01-12
 * Time: 07:14:20
 * To change this template use File | Settings | File Templates.
 */
public class StripesLocalePicker extends  DefaultLocalePicker {
   public static final String LOCALE = "org.apache.struts.action.LOCALE";
    
    public Locale pickLocale(HttpServletRequest request) {
        Locale locale = null;
        /*Page page = (Page) request.getAttribute("page");
        if (page != null){
            if (Language.DANISH.equals(page.getLanguage())){
                locale = new Locale("da_DK");
            }
            else{
                locale = new Locale("en_US");
            }
        }
        else{*/
        locale = (Locale) request.getSession().getAttribute(LOCALE);
        //}
        if (locale!=null){
            return locale;
        }
        else{
            return super.pickLocale(request);
        }
    }
}
