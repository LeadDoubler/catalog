package org.mortena.stripes.conf;

import net.sourceforge.stripes.controller.NameBasedActionResolver;


/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2006-12-20
 * Time: 10:47:16
 * To change this template use File | Settings | File Templates.
 */
public class MyActionResolver extends NameBasedActionResolver {
    @Override
    public String getBindingSuffix() { return ".do"; /* ugh */ }
}