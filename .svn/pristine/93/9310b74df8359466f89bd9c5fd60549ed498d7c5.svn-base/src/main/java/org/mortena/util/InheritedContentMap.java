/*
 * InheritedContentMap.java
 *
 * Created on 9. marts 2007, 08:22
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.mortena.util;

import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.Part;
import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.LogFactory;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author mortenandersen
 */
public class InheritedContentMap extends HashMap {
    
    Page page;
    
    /** Creates a new instance of InheritedContentMap */
    public InheritedContentMap() {
    }
    
    public InheritedContentMap(Page page){
        //LogFactory.getLog(InheritedContentMap.class).inf("Creating InheritedContentMap");
        //this.putAll(page.getParts());
        this.page = page;
    }
    
    public Object get(Object key){
        //LogFactory.getLog(InheritedContentMap.class).warn("GETTING PART "+key);
        long s = System.currentTimeMillis();
        if ( page == null || page.getParts() == null ) return null;
        try{
        Part value = page.getParts().get( key );
        
        List<Part> parts = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Part.class)
            .add(Restrictions.eq("page",page)).add(Restrictions.eq("name",key)).list();
        
        if(!parts.isEmpty())
            value = parts.get(0);
        
            //= super.get(key);

            if (value == null || value.getContent() == null || value.getContent().length() == 0){
                if (page != null && page.getParent() != null){
                    if ( page.getParent().getViewParts() != null){
                        value = (Part) page.getParent().getViewParts().get(key);
                    }
                }
            }
            long e = System.currentTimeMillis();
            LogFactory.getLog(InheritedContentMap.class).warn("Time to get part = "+(e-s));
            return value;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }        
    }
}
