package org.mortena.stripes.conf;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.controller.NameBasedActionResolver;
import net.sourceforge.stripes.exception.StripesServletException;


/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2006-12-20
 * Time: 10:47:16
 * To change this template use File | Settings | File Templates.
 */
public class LocaleActionResolver extends NameBasedActionResolver {
    
   
    
    public ActionBean getActionBean(ActionBeanContext context,
                                String path)
                         throws StripesServletException{
        return super.getActionBean(context,path);        
    }
}