package org.mortena.stripes.conf;

import com.asap.catalog.dao.Book;
import com.asap.catalog.dao.Category;
import com.asap.catalog.dao.Component;
import com.asap.catalog.dao.Course;
import com.asap.catalog.dao.Department;
import com.asap.catalog.dao.Event;
import com.asap.catalog.dao.Location;
import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.Part;
import com.asap.catalog.dao.Product;
import com.asap.catalog.dao.ProductShopCartItem;
import com.asap.catalog.dao.Request;
import com.asap.catalog.dao.Seminar;
import com.asap.catalog.dao.ShopCart;
import com.asap.catalog.dao.ShopCartItem;
import com.asap.catalog.dao.ShopCartOrder;
import com.asap.catalog.dao.Term;
import com.asap.catalog.dao.TermShopCartItem;
import com.asap.catalog.dao.User;
import com.asap.util.OrderTypeConverter;
import com.asap.venture.dao.ProjectDescription;
import com.asap.web.page.PageTypeConverter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import net.sourceforge.stripes.validation.DateTypeConverter;

import net.sourceforge.stripes.validation.DefaultTypeConverterFactory;
import net.sourceforge.stripes.config.Configuration;
import net.sourceforge.stripes.util.ResolverUtil;
import org.hibernate.criterion.Order;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-02-09
 * Time: 17:21:34
 * To change this template use File | Settings | File Templates.
 */
public class CatalogTypeConverterFactory extends DefaultTypeConverterFactory {
    
    public void init (Configuration configuration) {
        
        super.init (configuration);
        add (Date.class, DateTypeConverter.class);
        add (Page.class, PageTypeConverter.class);
        add (Part.class, LongTypeConverter.class);
        add (Book.class, LongTypeConverter.class);
        add (User.class, LongTypeConverter.class);
        add (Category.class, LongTypeConverter.class);
        add (Course.class, LongTypeConverter.class);
        add (Seminar.class, LongTypeConverter.class);
        add (Location.class, LongTypeConverter.class);
        add (Department.class, LongTypeConverter.class);
        add (Event.class, LongTypeConverter.class);
        add (Term.class, LongTypeConverter.class);
        add (Product.class, LongTypeConverter.class);
        add (ShopCart.class, LongTypeConverter.class);
        add (Request.class, LongTypeConverter.class);
        add (ShopCartItem.class, LongTypeConverter.class);
        add (ShopCartOrder.class, LongTypeConverter.class);
        add (ProductShopCartItem.class, LongTypeConverter.class);
        add (TermShopCartItem.class, LongTypeConverter.class);
        add (ProjectDescription.class,LongTypeConverter.class);
        add ( Order.class , OrderTypeConverter.class);
        
       /* ResolverUtil<Object> resolverUtil = new ResolverUtil<Object>();
        resolverUtil.findAnnotated(Entity.class);
        Set<Class <? extends Object>> entities = resolverUtil.getClasses();
        for(Class component : entities){
            try{
                this.add(component,LongTypeConverter.class);                    
                System.out.println("Added Component to typeconverter = "+component.getName());
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }*/
        
        ResolverUtil<Component> resolver = new ResolverUtil<Component>();
        ArrayList locations = new ArrayList();
        locations.add("WEB-INF/classes");
        resolver.setLocationFilters(locations);
        resolver.loadImplementationsFromContextClassloader(Component.class);
        Set<Class<? extends Component>> components = resolver.getClasses();
        for(Class component : components){
            try{
                this.add(component,LongTypeConverter.class);                    
                //System.out.println"Added Component to typeconverter = "+component.getName());
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}
