import com.asap.catalog.dao.User;
import java.util.List;

/*import org.hibernate.Session;
import org.hibernate.criterion.Property;

import com.asap.catalog.dao.Book;
import com.asap.catalog.dao.manager.BookManager;
import com.asap.security.Role;
import com.asap.security.UserManager;
import util.HibernateUtil;

public class Test {

    public static void main(String[] args) {
		// Create an administrator
		User jens = new User();
		jens.setUsername("jens");
		jens.setPassword("start");
		jens.setFirstName("Jens");
		jens.setLastName("Rosenberg");
		jens.setEmail("jens@blobcom.com");
		jens.setRole(Role.ADMINISTRATOR);
		UserManager.saveOrUpdateUser(jens);
		
		// Create a book
		Book book = new Book();
		book.setTitle("Battle of the beasts");
		book.setAuthor("Joan Beckett");
		book.setIsbn("05040303BX");
		BookManager.addBook(book);
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Property usernameProp = Property.forName("username");
		User user = null;
		List users = session.createCriteria(User.class).add(
				usernameProp.eq("root")).list();
		session.getTransaction().commit();
		session.close(); 

		System.out.println("stop");
		if (user == null) {
			System.out.println("user null1");
		} else {
			if (users.size() == 0) {
				System.out.println("user null2");
			} else if (users.get(0) instanceof User) {
				System.out.println(users.size());
				user = (User) users.get(0);
			}
		}
		System.out.println("OK");
	}
}
*/