package pictures;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2006-08-23
 * Time: 12:16:03
 * To change this template use File | Settings | File Templates.
 */
public class PictureUtil {
    private static int width = 150;

    private static Log log = LogFactory.getLog(PictureUtil.class);


    public static File scalePicture(File inputFile){
        File outFile = null;
        BufferedImage image =  null;// ImageIO.read(outFile);
        try {

            image = ImageIO.read(new FileInputStream(inputFile));
            BufferedImage res = scaleBinary(image, inputFile);


            //BufferedImage bi = toBufferedImage(scaled, BufferedImage.TYPE_INT_RGB);
            log.warn("after toBufferedImage");

            outFile = new File(inputFile.getParentFile(),getNameOfFile(inputFile)+"_mini.jpg");
            outFile = getFirstAvailableFile(outFile);
            ImageIO.write(res, "jpeg", outFile);
            log.warn("after file has been written");
            res.flush();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return outFile;
    }

    public static BufferedImage scaleBinary(final BufferedImage image, final File inputFile) throws IOException {

        //-1 makes the height follow the original relation between height and width
        Image scaled;
        log.warn("before getScaledInstance");
        if (image.getWidth()>150){
            scaled = image.getScaledInstance(width, -1, BufferedImage.SCALE_SMOOTH);
        }
        else {
            scaled = image;
        }
        log.warn("before toBufferedImage");

        BufferedImage bi = readImage(inputFile);
        BufferedImage res = scaleImage(bi);
        return res;
    }

    /**
     * Inspired from: http://forum.java.sun.com/thread.jspa?forumID=20&threadID=522483
     * @param bi
     * @return scaled image
     */
    public static BufferedImage scaleImage(BufferedImage bi) {
        int width = 150;
        int height = -1;
        return scale(bi, width, height);
    }

    public static BufferedImage scale(final BufferedImage bi, final int width, final int height) {
        double tWidth;
        double tHeight;
        double scalex = 1;
        double scaley = 1;
        if ( height == -1 ){
            scalex = (double)  width / bi.getWidth();
        }
        else{
            tHeight = height;
        }
        if (width == -1){
            scaley = (double)  height / bi.getHeight();
        }
        else{
            tWidth = width;
        }
        tWidth =  scaley*bi.getWidth();
        tHeight = scalex*bi.getHeight();
       
        //log.warn("width and height = "+tHeight+" width = "+tWidth+" Original width = "+bi.getWidth());
        BufferedImage res = new BufferedImage((int)tWidth, (int)tHeight, BufferedImage.TYPE_INT_RGB);

        Graphics2D g2 = res.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        //double scaley = (double) 200/ bi.getHeight();
        AffineTransform xform = AffineTransform.getScaleInstance(scalex, scaley);
        g2.drawRenderedImage(bi, xform);
        g2.dispose();
        return res;
    }
    
    public static BufferedImage scaleImageByHeight(BufferedImage bi,int newHeight) {
        double scalex = (double) newHeight/ bi.getHeight();
        double tHeight =  scalex*bi.getHeight();
        double tWidth =  scalex*bi.getWidth();
        log.warn("width and height = "+tHeight+" width = "+tWidth+" Original width = "+bi.getWidth());
        BufferedImage res = new BufferedImage((int)tWidth, (int)tHeight, BufferedImage.TYPE_INT_RGB);

        Graphics2D g2 = res.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        //double scaley = (double) 200/ bi.getHeight();
        AffineTransform xform = AffineTransform.getScaleInstance(scalex, scalex);
        g2.drawRenderedImage(bi, xform);
        g2.dispose();
        return res;
    }
    
    public static BufferedImage scaleImage(BufferedImage bi,int newwidth) {
        double scalex = (double) newwidth/ bi.getWidth();
        double tWidth =  scalex*bi.getWidth();
        double tHeight =  scalex*bi.getHeight();
        log.warn("width and height = "+tHeight+" width = "+tWidth+" Original width = "+bi.getWidth());
        BufferedImage res = new BufferedImage((int)tWidth, (int)tHeight, BufferedImage.TYPE_INT_RGB);

        Graphics2D g2 = res.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        //double scaley = (double) 200/ bi.getHeight();
        AffineTransform xform = AffineTransform.getScaleInstance(scalex, scalex);
        g2.drawRenderedImage(bi, xform);
        g2.dispose();
        return res;
    }

    /**
     * From: http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4705399
     * @param source
     * @return
     * @throws IOException
     */
    public static BufferedImage readImage(Object source) throws IOException {
        ImageInputStream stream =  ImageIO.createImageInputStream(source);
        ImageReader reader = (ImageReader) ImageIO.getImageReaders(stream).next();
        reader.setInput(stream);
        ImageReadParam param = reader.getDefaultReadParam();

        ImageTypeSpecifier typeToUse = null;
        for (Iterator i = reader.getImageTypes(0); i.hasNext();) {
            ImageTypeSpecifier type = (ImageTypeSpecifier) i.next();
            if (type.getColorModel().getColorSpace().isCS_sRGB()){
                typeToUse = type;
            }
        }
        if (typeToUse != null){
            param.setDestinationType(typeToUse);
        }

        BufferedImage b = reader.read(0, param);
        reader.dispose();
        stream.close();
        return b;
    }


    public static BufferedImage toBufferedImage(java.awt.Image image, int type) {
        int w = image.getWidth(null);
        int h = image.getHeight(null);
        BufferedImage result = new BufferedImage(w, h, type);
        Graphics2D g = result.createGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();
        return result;
    }

    public static String getNameOfFile(File file){
        return file.getName().split("\\.")[0];

    }

    public static String getTypeOfFile(File file){
        return file.getName().split("\\.")[1];
    }

    public static File getFirstAvailableFile(File outputFile) {
        String[] split =  outputFile.getName().split("\\.");
        String name = split[0];
        String type = split[1];
        int i = 1;
        while ( outputFile.exists() ){
            outputFile = new File(outputFile.getParentFile(), name+"_"+i+"."+type);
            i++;
        }
        return outputFile;
    }
}

