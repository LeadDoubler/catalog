/*
 * PageTypeConverter.java
 *
 * Created on 18. marts 2007, 09:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.page;

import com.asap.catalog.dao.Page;
import java.util.Collection;
import java.util.List;
import org.hibernate.criterion.Expression;
import org.mortena.stripes.conf.LongTypeConverter;
import util.HibernateUtil;

/**
 *
 * @author mortenandersen
 */
public class PageTypeConverter extends LongTypeConverter{
    
    /** Creates a new instance of PageTypeConverter */
    public PageTypeConverter() {
    }
    
    public Object convert(String s, Class aClass, Collection collection) {        
        try{
            Long.parseLong(s);
            return super.convert(s,aClass,collection);
        }catch (NumberFormatException ne){
            if (s == null || s.equals("null")){
                return null;
            }
            Page page = (Page) HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(aClass).add(Expression.eq("url",s)).uniqueResult();
            if (page == null){
                List<Page> pages = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Page.class).add(Expression.like("title", s)).list();
                if (pages != null && pages.size()>0){
                    page = pages.get(0);
                }
            }
            /*if (page == null){
                page = new Page();
                page.setUrl(s);
                HibernateUtil.getSessionFactory().getCurrentSession().save(page);             
            }*/
            return page;
        } 

    }
}
