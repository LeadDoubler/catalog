package com.asap.catalog.dao;

import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import org.hibernate.validator.NotNull;


@Entity
@DiscriminatorValue("product")
public class ProductShopCartItem extends ShopCartItem {

    @ManyToOne(optional=true, fetch=FetchType.EAGER)
    private Product product;
    
    public String getDescription() {
        return product.getTitle();
    }
    
    public String getName() {
        return product.getTitle();
    }
    
    public Double getPrice() {
        return product.getPrice();
    }
    
    public boolean equalsItem(Object item) {
        if (item instanceof ProductShopCartItem) {
            return product.getId().intValue() == ((ProductShopCartItem) item).getId().intValue();
        }
        return false;
    }

    public Product getProduct () {
        return product;
    }

    public void setProduct (Product product) {
        this.product = product;
    }
    
}
