/*
 * ProjectDescriptionManager.java
 *
 * Created on 28. marts 2007, 21:28
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao.manager;

import com.asap.venture.dao.ProjectDescription;
import java.util.Collection;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;

/**
 *
 * @author mortenandersen
 */
public class ProjectDescriptionManager implements Manager{
    String text;
    private String language;
    
    /** Creates a new instance of ProjectDescriptionManager */
    public ProjectDescriptionManager() {
    }

    public void setText(String text) {
        this.text = text;
    }

    public Collection getResults() {
        String search = "%"+text+"%";
        Criteria crit = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(ProjectDescription.class);
        crit.add(
                Expression.or(
                    Expression.like("ipr",search),
                    Expression.or(
                        Expression.like("management",search),
                        Expression.or(
                            Expression.like("title",search),
                            Expression.like("business",search)
                        )
                    )
                )
        );
        return crit.list();
    }

    public String getUrl() {
        return "projectDescription";
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    
    
}
