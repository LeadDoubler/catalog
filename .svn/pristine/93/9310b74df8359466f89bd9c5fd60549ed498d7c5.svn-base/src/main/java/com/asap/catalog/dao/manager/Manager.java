/*
 * Manager.java
 *
 * Created on 28. marts 2007, 20:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao.manager;

import java.util.Collection;
import java.util.List;

/**
 *
 * @author mortenandersen
 */
public interface Manager {
    
    public void setText(String text);
    
    public Collection getResults();
    
    public String getUrl();
    
    public String getLanguage();
    
    public void setLanguage(String lang);
    
}
