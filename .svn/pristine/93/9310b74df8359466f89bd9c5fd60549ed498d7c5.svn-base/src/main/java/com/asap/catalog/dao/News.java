package com.asap.catalog.dao;
/*
 * news.java
 *
 * Created on 31. maj 2007, 09:28
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import org.hibernate.annotations.Type;

/**
 *
 * @author Jens Rosenberg
 */
@Entity
@Table(name = "news")
public class News extends Component{
    @Transient
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM-yyyy HH:mm");
    
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Type(type = "text")
    private String description;
    
    private String title;
    
    private String url;
    
    @ManyToOne
    private Page page;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column (name = "releaseDate")
    private Date date;
    
    public String getTitle() {
        return title;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public String getStringDate() {
        if(date == null) return "";
        else return sdf.format(date);
    }
    
    public void setStringDate(String date) throws ParseException {
        if(date == "" || date == null) this.date = null;
        else this.date = sdf.parse(date);
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
     public String getLink(){
        if(page != null && (url == null || url.length()==0) ){
            return "/page/"+page.getId();
        }else{
            return url;
        }
    }
}
