/*
 * ShopcartOrder.java
 *
 * Created on 24. maj 2007, 12:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao;

import com.asap.catalog.enums.ShopCartOrderStatus;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Jens Rosenberg
 */
@Entity
@Table (name = "shopcartorder")
public class ShopCartOrder implements java.io.Serializable{
    
    @ManyToOne
    private ShopCart shopcart;
    
    @ManyToOne
    private Customer customer;
    
    @Temporal(value = TemporalType.TIMESTAMP)
    private Date date;
    
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;
    
    private ShopCartOrderStatus status = ShopCartOrderStatus.NOTORDERED;
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public ShopCart getShopcart() {
        return shopcart;
    }

    public void setShopcart(ShopCart shopcart) {
        this.shopcart = shopcart;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public String toString() {
        if(getId() != null) return getId()+"";
        else return null;
    }

    public ShopCartOrderStatus getStatus() {
        if(status == null){
            return ShopCartOrderStatus.NEW;
        }
        return status;
    }

    public void setStatus(ShopCartOrderStatus status) {
        this.status = status;
    }
    
       public String getPaymentForm() {
        return paymentForm;
    }

    public void setPaymentForm(String paymentForm) {
        this.paymentForm = paymentForm;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public boolean isDeliver() {
        return deliver;
    }

    public void setDeliver(boolean deliver) {
        this.deliver = deliver;
    }
    
    private String paymentForm;
        private String location;
        private String comment;
        private boolean deliver;
        private String pickupDay;
	private boolean approved;

    public String getPickupDay() {
        return pickupDay;
    }

    public void setPickupDay(String pickupDay) {
        this.pickupDay = pickupDay;
    }
}
