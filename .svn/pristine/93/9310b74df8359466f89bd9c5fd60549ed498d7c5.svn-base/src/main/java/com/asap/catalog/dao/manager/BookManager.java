package com.asap.catalog.dao.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Property;

import util.HibernateUtil;

import com.asap.catalog.dao.Book;

public class BookManager {

	public List<Book> getAllBook() {

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		// session.beginTransaction();
		List<Book> book = (List<Book>) session.createCriteria(Book.class).list();
		// session.getTransaction().commit();
		// session.close();
		return book;
	}

	public static Book getBook(Long id) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		// session.beginTransaction();
		Property property = Property.forName("id");
		Book book = (Book) session.createCriteria(Book.class).add(
				property.eq(id)).uniqueResult();
		// session.getTransaction().commit();
		// session.close();
		System.out.print(book.getIsbn());
		return book;
	}

	public static Collection<Book> getBookCollection() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		List<Book> bookList = (List<Book>) session.createCriteria(Book.class)
				.list();
		// session.close();
		if (bookList.size() == 0) {
			List<Book> list = new ArrayList<Book>();
			Book book = new Book();
			book.setTitle("title");
			book.setId(new Long(-1));
			list.add(book);
			return list;
		}

		return bookList;
	}

	public static void addBook(Book book) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		// session.beginTransaction();
		session.saveOrUpdate(book);
		// session.getTransaction().commit();
		// session.close();
	}
}
