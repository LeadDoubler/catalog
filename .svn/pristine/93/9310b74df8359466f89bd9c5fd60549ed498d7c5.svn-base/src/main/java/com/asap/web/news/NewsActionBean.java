/*
 * newsActionBean.java
 *
 * Created on 31. maj 2007, 09:44
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.news;

import com.asap.catalog.dao.News;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.blob.pas.DefaultActionBean;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import org.hibernate.Criteria;
import org.hibernate.classic.Session;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Jens Rosenberg
 */
public class NewsActionBean extends DefaultActionBean{
    
    private News news;
    private Long nr;
    
    /** Creates a new instance of NewsActionBean */
    public NewsActionBean() {
    }
    
    public News getNews(){
        return news;
    }
    
    public void setNews(News news){
        this.news = news;
    }

    public String getType() {
        return "news";
    }

    public Object getComponent() {
        return news;
    }

    public List<Object> getComponents() {
        Criteria crit = getSession().createCriteria(News.class).addOrder(Order.asc("date"));
        if (getNr() != null && getNr() > 0 ){
            crit.setFetchSize(getNr().intValue());
        }
        crit.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
        return crit.list();
    }

    public String getEditorFolder() {
        return getType();
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution save(){
        getSession().saveOrUpdate(news);
        return new ForwardResolution("/news/showAll.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution delete(){
       getSession().delete(news);
       return new ForwardResolution("/news/showAll.jsp");
    }
    
    public Resolution list(){
       return new ForwardResolution("/news/list.jsp");
    }
    
    public Resolution json(){
       return new ForwardResolution("/news/json.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution showAll(){
       return new ForwardResolution("/news/showAll.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution edit(){
        return new ForwardResolution("/news/edit.jsp");
    }
    
    public int getNrOfNews(){
        return getSession().createCriteria(News.class).addOrder(Order.asc("date")).list().size();
    }
    
    public List<News> getNextNews() {
        /*Calendar cal = new GregorianCalendar();
        cal.setTime(new Date());
        Date date1 = cal.getTime();
        cal.roll(Calendar.WEEK_OF_YEAR,2);

        Date date2 = cal.getTime();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        return session.createCriteria(News.class)
            .add(Restrictions.between("date",date1,date2))
            .addOrder(Order.asc("date")).setMaxResults(6).list();*/
        List<News> list;
        
        if(getNr() != null){
            list  = getSession().createCriteria(News.class).addOrder(Order.desc("date")).setMaxResults(getNr().intValue()).setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY).list();
        }else{
            list  = getSession().createCriteria(News.class).addOrder(Order.desc("date")).setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY).list();
        }
        

        return list;
    }

    public Long getNr() {
        return nr;
    }

    public void setNr(Long nr) {
        this.nr = nr;
    }
}
