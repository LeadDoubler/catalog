package com.asap.catalog.dao.manager;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Property;

import util.HibernateUtil;

import com.asap.catalog.dao.Course;

public class CourseManager {

	public List<Course> getAllCourse() {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//		session.beginTransaction();
		List<Course> course = (List<Course>) session.createCriteria(
				Course.class).list();
//		session.getTransaction().commit();
//		session.close();
		return course;
	}

	public static void addCourse(Course course) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//		session.beginTransaction();
		session.saveOrUpdate(course);
//		session.getTransaction().commit();
//		session.close();
	}

	public static Course getCourse(Long id) {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//		session.beginTransaction();
		Property property = Property.forName("id");
		Course course = (Course) session.createCriteria(Course.class).add(
				property.eq(id)).uniqueResult();
//		session.getTransaction().commit();
//		session.close();
		return course;
	}
}
