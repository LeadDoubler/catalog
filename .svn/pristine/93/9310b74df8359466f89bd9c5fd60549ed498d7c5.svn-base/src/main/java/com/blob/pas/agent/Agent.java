/*
 * Agent.java
 *
 * Created on 26. maj 2007, 09:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.blob.pas.agent;

import java.util.Date;
import org.quartz.Job;

/** 
 *
 * @author mortenandersen
 */
public interface Agent {
    
    public Job getJob();
    
    public Date getStartDate();
    
    public String getName();
    
    public String getGroup();
    
    public int getSecondsBetweenRun();
    
}
