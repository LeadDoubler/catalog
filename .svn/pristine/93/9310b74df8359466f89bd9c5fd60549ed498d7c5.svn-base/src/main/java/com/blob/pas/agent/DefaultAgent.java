/*
 * DefaultAgent.java
 *
 * Created on 13. juni 2007, 11:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.blob.pas.agent;

import java.util.Date;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StaleObjectStateException;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import util.HibernateUtil;

/**
 *
 * @author mortenandersen
 */ 
public abstract class DefaultAgent implements Agent,Job{
    public static final int HOUR = 60*60;
    public static final int DAY = 24*HOUR;
    public static final int WEEK = 7*DAY;
    public static final int MONTH = 31*DAY;
    
    /** Creates a new instance of DefaultAgent */
    public DefaultAgent() {
    }
    
     public Job getJob() {
        return this;
    }
     
     public abstract void execute();
     
    public Date getStartDate() {
        return new Date();
    }

    public String getName() {
        return this.getClass().getName();
    }

    public String getGroup() {
        return "Agent";
    }

    /**
     *Must return number of seconds in 14 days
     */
    public int getSecondsBetweenRun() {
        return 30;
    }

    
      public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        runMe();
    }
      
      public void runMe() {
        SessionFactory sf = HibernateUtil.getSessionFactory();  
        Session session = sf.getCurrentSession();
        try {
            session.beginTransaction();
            //log.info("Starting a database transaction ");
             //sf.getCurrentSession().beginTransaction();

            // Call the next filter (continue request processing)
            this.execute();//chain.doFilter(request, response);

            // Commit and cleanup
            //org.mortena.netvaerk.HibernateRequestFilter.log.info("Committing the database transaction");
            session.getTransaction().commit();
        } catch (StaleObjectStateException staleEx) {
            // Rollback, close everything, possibly compensate for any permanent changes
            // during the conversation, and finally restart business conversation. Maybe
            // give the user of the application a chance to merge some of his work with
            // fresh data... what you do here depends on your applications design.
            staleEx.printStackTrace();
        } catch (Throwable ex) {
            // Rollback only
            ex.printStackTrace();
            try {
                if (session.getTransaction().isActive()) {
                    session.getTransaction().rollback();
                }
            } catch (Throwable rbEx) {
            }

            // Let others handle it... maybe another interceptor for exceptions?
            ex.printStackTrace();
        }
        finally{
            //session.disconnect();
            //HibernateUtil.getSessionFactory().close();
            //session.close();
        }
    }
    
}
