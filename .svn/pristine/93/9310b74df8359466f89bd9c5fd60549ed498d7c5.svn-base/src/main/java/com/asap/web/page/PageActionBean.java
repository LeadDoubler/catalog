package com.asap.web.page;

import com.asap.catalog.enums.BannerType;
import com.asap.catalog.enums.Language;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.web.CatalogActionBean;
import com.asap.catalog.dao.Page;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import net.sourceforge.stripes.action.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-02-09
 * Time: 20:12:57
 * To change this template use File | Settings | File Templates.
 */

public class PageActionBean extends CatalogActionBean {
    private Log log = LogFactory.getLog(ShowActionBean.class);
    private String url;
    
    private Page page;
    private Page oldParent;
    private Page newParent;
    private FileBean photo;
    private boolean imageactive = true;
    
    @Secure(role = Role.CORRECTOR)
    public Resolution listDeactivated(){
        return new ForwardResolution("/page/listDeactivatedPages.jsp");
    }
    
     @Secure(role = Role.CORRECTOR)
    public Resolution listHidden(){
        return new ForwardResolution("/page/listHiddenPages.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution deactivate(){
        page.changeDeactivateionChildrenTo("yes");
        return new ForwardResolution("/page/listDeactivatedPages.jsp");
    }
    
    
    @Secure(role = Role.CORRECTOR)
    public Resolution activate(){
        page.changeDeactivateionChildrenTo("no");
        return new ForwardResolution("/page/Show.action?page="+page);
    }
    
    public Page getPage () {
        return page;
    }
    
    public void setPage (Page page) {
        this.page = page;
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution init (){
        return new ForwardResolution ("/page/edit.jsp");
    }
    
    public Resolution tabs() {
        return new ForwardResolution ("/layout/topnav.jsp");
    }
    
    public Resolution menu() {
        return new ForwardResolution ("/layout/menu.jsp");
    }
    
    @DefaultHandler
    public Resolution view() {
        return new RedirectResolution("/page/Show.action?page="+page);
       /* log.warn("SHOWING PAGE");
        if (page == null){
            Page pageToShow = (Page) getSession().createCriteria(Page.class).add(Expression.like("url",url)).uniqueResult();
            if (pageToShow == null){
                return new RedirectResolution("/startup/Startup.action?dansk");
                //pageToShow = (Page) getSession().load( Page.class , new Long(1) ) ;
            }
            //setPage(pageToShow);
        }
        log.info("Setting session.page = "+page);
        this.getContext().getRequest().getSession().setAttribute("page",page);
        this.getContext().getRequest().setAttribute("page",page);
        if (page != null && page.getForward()!= null && page.getForward().length()>0){
            if (page.getForward().endsWith(".jsp")){                
                return new ForwardResolution(page.getForward());
            }  
            else{
                return new RedirectResolution(page.getForward());
            }
        }
        else{
            return new ForwardResolution("/page/showPage.jsp");
        }*/
    }
    
    @Secure(role = Role.ADMINISTRATOR)
    public Resolution editMetaTags (){
        newParent = page.getParent();
        oldParent = page.getParent();
        return new ForwardResolution ("/page/editMetaTags.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution edit (){
        newParent = page.getParent();
        oldParent = page.getParent();
        if (page.getId()== null){
            page.setHide("no");
        }
        return new ForwardResolution ("/page/edit.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution inline (){
        return new ForwardResolution ("/page/inlineEdit.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution inlineNew (){
        return new ForwardResolution ("/page/inlineAdd.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution inlineAdd (){
        HibernateUtil.getSessionFactory ().getCurrentSession ().saveOrUpdate (getPage());
        return new RedirectResolution ("/segment/Segment.action?editMenu");
    }
   
    @Secure(role = Role.CORRECTOR)
    public Resolution inlineSave (){
        HibernateUtil.getSessionFactory ().getCurrentSession ().saveOrUpdate (getPage());
        saveXML();
        return new ForwardResolution ("/page/inlineView.jsp");
    }
    
   /* public Resolution image () {
         if ( page != null || page.getPicture_binary () != null ){
            InputStream reader = new ByteArrayInputStream (page.getPicture_binary ());
            return new StreamingResolution ( "image/jpg", reader);
         }
         else return null;
    
    }*/
    
    @Secure(role = Role.CORRECTOR)
    public Resolution moveDown(){
        int move = 1;
        saveXML();
        return move(move);
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution moveUp(){
        int move = -1;
        saveXML();
        return move(move);
    }
    
    @Secure(role = Role.CORRECTOR)
    private Resolution move(final int move) throws HibernateException {
        long position = page.getPagePosition();
        page.getParent().initializeChildren();
        Collection<Page> children = page.getParent().getMyChildren();
        for ( Page p : children ){
            //System.out.println"p = "+p);
        }
        /*int oldPosition = children.indexOf(page);
        long newPosition = oldPosition+move;
        */
        int i = 0;
        boolean breakNow = false;
        Page p2 = null;
        for (Page p: children){
            if(p == null){
                //System.out.println"p == null");
            }
            if (breakNow){
                p.getId();
                p2 = p;
                break;
            }
            if (page.getId() == p.getId()){
                if (move < 0){
                    break;
                }
                else{
                    breakNow = true;
                }
            }
            i++;
            p2 = p;
        }
        if (p2 !=null){
            page.setPagePosition(p2.getPagePosition());
            p2.setPagePosition(position); 
            getSession().saveOrUpdate(p2);
            getSession().saveOrUpdate(page);
        }
        /*
        if ( ! (i+move<0 || i+move >= children.size() )){
            Page p = children.get(i+move);
            if (p!=null){
                
                
            }
            else{
                //System.out.println"p == null");
            }
            
        }*/
        /*
        for ( Page p : children ){
            //System.out.println"p = "+p);
            if (p != null && p.getPagePosition() == position+move){
                p.setPagePosition(position);
                page.setPagePosition(position+move);  
                getSession().saveOrUpdate(p);
                getSession().saveOrUpdate(page);
            }
        }*/
        return new RedirectResolution("/page/Show.action?page="+getPage().getId ());
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution save (){
        savePhoto();
        setBannertype();
        secureUniqueURLMap();
        if(newParent!=null) {
            page.setParent(newParent);
        }
        //If old and newparent is the same. Then nothing should be done. Else move page - last position
        if ( oldParent != null && oldParent.equals(newParent) ){
            
        }
        else{
            if(newParent != null){
                int size = newParent.getMyChildren().size();
                if(oldParent != null){
                    //oldParent.getChildren().remove(page);
                }
                page.setPagePosition(  size  );
            }
            else{
                newParent = page.getParent();
                if (newParent != null){
                    int size = newParent.getMyChildren().size();
                    if(oldParent != null){
                        //oldParent.getChildren().remove(page);
                    }
                    page.setPagePosition(  size  );
                }
            }
        }
        /*
        //If oldParent != newParent - The page is new or has been moved.
        if (oldParent == null || ! oldParent.getId().equals( page.getParent().getId() ) ){
            //page.setPagePosition(page.getParent().getChildren().size());
            page.getParent().getChildren().add(page);
        }*/
        
        // Inherit parent language
        if(getPage().getLanguage () == null || getPage().getLanguage () == Language.NONE){
            if(getPage().getParent () != null){
                getPage().setLanguage (getPage().getParent ().getLanguage ());
            }else{
                getPage().setLanguage (Language.NONE);
            }
        }
        
        /*if (isDoShow()){
            getPage().setHide("no");
        }
        else{
            getPage().setHide("yes");
        }*/
        HibernateUtil.getSessionFactory ().getCurrentSession ().saveOrUpdate (getPage());
        saveXML();
        this.updatePagePositions(page.getParent());
       
        return new RedirectResolution ("/page/Show.action?page="+getPage().getId ());
    }

    private void secureUniqueURLMap() throws HibernateException {
        
        
        
        // Securing unique UrlMap
        if(getPage().getUrlMap () != null && getPage().getUrlMap () != ""){
            List<Page> pages = getSession ().createCriteria (Page.class)
            .add (Restrictions.eq ("urlMap",getPage().getUrlMap ()))
            .add (Restrictions.eq ("language",getPage().getLanguage ()))
            .add (Restrictions.ne ("id",getPage().getId ())).list ();
            
            Iterator it = pages.iterator();
            while(it.hasNext()){
                Page p = (Page)it.next();
                p.setUrlMap(null);
                HibernateUtil.getSessionFactory().getCurrentSession().saveOrUpdate(p);
            }
        }
    }

    private void setBannertype() {
        
        if(isImageactive() == false){
            getPage().setBanner_type (BannerType.NONE);
        }
    }

    private void savePhoto() {
        
        if (getPhoto()!=null) {
            String type = getPhoto().getContentType ();
            getPage().setBanner_type(BannerType.getBannerType(type));
            
            if (getPage().getBanner_type () != BannerType.NONE) {
                byte[] bytes = new byte[(int)getPhoto().getSize ()];
                try {
                    InputStream istream = getPhoto().getInputStream ();
                    istream.read (bytes);
                    getPage().setPicture_binary (bytes);
                } catch (IOException ex) {
                    ex.printStackTrace ();
                }
            }
        }
    }
    
    private void saveXML(){
        String path = this.getContext().getServletContext().getRealPath("menu/menu.xml");
        File file = new File(path);
        file.getParentFile().mkdirs();
        String content = page.getRoot().getXml();
        FileWriter out;
        try {
            out = new FileWriter(file);
            out.write(content);
            out.close();
            //System.out.println"Menu written to: "+file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @Secure(role = Role.CORRECTOR)
    public List<Page> getAllPages (){
        List<Page> pages = getSession ().createCriteria (Page.class).list ();
        ArrayList children = new ArrayList ();
        ArrayList<Page> toReturn = new ArrayList ();
        if (getPage() == null){
            System.out.print ("page == null");
            return pages;
        }
        System.out.println ("Getting all pages");
        getPage().addAllChildren (children);
        children.add (getPage());
        for (Iterator<Page> iterator = pages.iterator (); iterator.hasNext ();) {
            Page page1 = iterator.next ();
            if ( ! children.contains (page1)){
                toReturn.add (page1);
            }
        }
        return toReturn;
    }
    
   
    
    public FileBean getPhoto () {
        return photo;
    }
    
    public void setPhoto (FileBean photo) {
        this.photo = photo;
    }
    
    public boolean getImageactive () {
        return isImageactive();
    }
    
    public void setImageactive (boolean imageactive) {
        this.imageactive = imageactive;
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution delete (){
        Page parent = getPage().getParent ();
        // Handle deletion
        /*Page leftPage = getPage().getLeftPage ();
        Page rightPage = getPage().getRightPage ();
        if (leftPage != null) {
            leftPage.setRightPage (rightPage);
        }
        if (rightPage != null) {
            rightPage.setLeftPage (leftPage);
        }*/
        Collection<Page> children = parent.getMyChildren();
        boolean past = false;
        int i = 0;
        for (Page p : children ){//int pos = 0; pos < children.size() ; pos++){
            if (past){
                p.setPagePosition( i );
            }
            else{
                if ( p.getId() == page.getId() ){
                    past = true;
                    i--;
                }
            }
            i++;
        }
       
        getSession ().delete (getPage ());
        return new RedirectResolution ("/page/Show.action?page="+parent);
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution editPosition(){
        return new ForwardResolution("/page/EditPosition.jsp");
    }
    
    @Secure(role = Role.CORRECTOR)
    public Resolution saveNewPosition (){
        if (leftPage == null){
            Page firstPage = page.getParent().getSortedChildList().get(0);
            firstPage.setTheLeft(page);            
        }
        else{
            page.setTheLeft(leftPage);
        }
        if (move == -1){
            //System.out.println"MOVING UP");
        }
        else{
            //System.out.println"MOVING DOWN");
        }
        
        
        /*Page pLeft = page.getLeftPage();
        Page pRight = page.getRightPage();
         //Removing it from present pos.
        if (pLeft != null){           
            pLeft.setRightPage(pRight);        
            getSession().saveOrUpdate(pLeft);
        }
        if (pRight != null){
            pRight.setLeftPage(pLeft);            
            getSession().saveOrUpdate(pRight);
        }
        //Inserting it on new pos:
        if (leftPage != null){
            page.setLeftPage(leftPage);
            page.setRightPage(leftPage.getRightPage());
            leftPage.setRightPage( page );            
            getSession().saveOrUpdate(leftPage);
        }
        else{     
            Page firstPage = page.getParent().getSortedChildList().get(0);
            firstPage.setLeftPage(page);
            page.setRightPage(firstPage);
            page.setLeftPage(null);
            getSession().saveOrUpdate(firstPage);
        }        
        getSession().update(page);
        */
        
        /*
        
        if ( ( leftPage == null || leftPage.getId() == -1 ) && page.getLeftPage() !=null ){
            leftPage = page.getParent().getSortedChildList().get(0);
            pLeft.setRightPage(pRight);
            page.setLeftPage(null);
            page.setRightPage(leftPage);
            getSession().saveOrUpdate(pLeft);            
            getSession().saveOrUpdate(pRight);
            getSession().saveOrUpdate(page);
            getSession().saveOrUpdate(leftPage);
        }
        else if ( leftPage != null ){
            if (pLeft != null ){
                page.getLeftPage().setRightPage(pRight);
                getSession().saveOrUpdate(pLeft);   
            }
            page.setRightPage(leftPage.getRightPage());
            page.setLeftPage(leftPage);                     
            getSession().saveOrUpdate(pRight);
            getSession().saveOrUpdate(page);
            getSession().saveOrUpdate(leftPage);
        }*/
        return new RedirectResolution ("/page/Show.action?page="+page);
    }
    
    public boolean isImageactive() {
        return imageactive;
    }

    private Page leftPage;

   
    public Page getLeftPage() {
        return leftPage;
    }

    public void setLeftPage(Page leftPage) {
        this.leftPage = leftPage;
    }

    public Page getOldParent() {
        return oldParent;
    }

    public void setOldParent(Page oldParent) {
        this.oldParent = oldParent;
    }

    public Page getNewParent() {
        return newParent;
    }

    public void setNewParent(Page newParent) {
        this.newParent = newParent;
    }
    
    @Secure(role = Role.ADMINISTRATOR)
    public Resolution updateDatabase(){
        //String sql = "update page set pagePosition=-1 where pagePosition='null'";
        //getSession().createSQLQuery(sql);
        List<Page> pages =  getSession().createCriteria(Page.class).add(Expression.isNull("parent")).list();
        for (Page page : pages){
            updatePagePositions(page);
        }
        List<Page> allPages = getSession().createCriteria(Page.class).list();
        for (Page page: allPages){
            getSession().saveOrUpdate(page);
        }
        return new StreamingResolution("text/html","database updated");
    }
    
    @Secure(role = Role.CORRECTOR)
    private void updatePagePositions(final Page page) throws HibernateException, NumberFormatException {
        //page.initializeChildren();
        if (page != null){
            Collection<Page> children = page.getMyChildren();
            int i = 0;
            for ( Page child : children ){
                if(child != null){
                    child.setPagePosition(  i  );
                    getSession().saveOrUpdate(child);
                    //if (child.getPagePosition()!=200)
                    updatePagePositions(child);            
                }
                i++;
            }
        }
    }
    
    private int move;

    public int getMove() {
        return move;
    }

    public void setMove(int move) {
        this.move = move;
    }
    
    private boolean doShow ;

    private void hide(){
        if ( ! doShow ){
           // System.out.println("Hide = yes");
            getPage().setHide("yes");
        }
        else{
            getPage().setHide("no");
        }
        //System.out.println("After hide() + "+getPage().getHide());
    }
    
    public boolean isDoShow() {
        if ("yes".equals(getPage().getHide() ) ){
            return false;
        }
        else{
            return true;
        }
    }

    public void setDoShow(boolean doShow) {
        this.doShow = doShow;
    }
}
