package com.asap.web.part;

import com.asap.catalog.dao.Part;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.web.CatalogActionBean;
import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.Segment;
import net.sourceforge.stripes.action.*;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-02-09
 * Time: 20:12:57
 * To change this template use File | Settings | File Templates.
 */
public class PartActionBean extends CatalogActionBean {

    Part part;

    public Part getPart() {
        return part;
    }

    public void setPart(Part part) {
        this.part = part;
    }

    public Resolution init(){
        return new ForwardResolution("/part/edit.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution inline(){
        return new ForwardResolution("/part/inlineEdit.jsp");
    }
     
    /*@Secure(role = Role.MODERATOR)
    public Resolution inlineNew(){
        return new ForwardResolution("/part/inlineEdit.jsp");
    }
     
    @Secure(role = Role.MODERATOR)
    public Resolution inlineAdd(){
        HibernateUtil.getSessionFactory().getCurrentSession().saveOrUpdate(part);
        return new RedirectResolution("/part/inlineView.jsp");
    }*/
    
    @Secure(role = Role.MODERATOR)
    public Resolution inlineSave(){
        Page page = part.getPage();
        if(getPart().getContent() == null || getPart().getContent() == "" || getPart().getContent() == "<p></p>"){
            getSession().delete(part);
        }
        else{
            if (part.getId() == null){
                //new part added
                List list = getSession().createCriteria(Part.class).add(Expression.eq("page", page)).add(Expression.eq("name",part.getName())).list();
                if (list.size()>0){
                    Part foundPart = (Part) list.get(0);
                    if (foundPart != null){
                        //Trying to overwrite existing part.
                        foundPart.setContent(part.getContent());
                        part = foundPart;
                        getSession().saveOrUpdate(part);
                        return new ForwardResolution("/part/view.jsp");    
                    }
                }
                else{
                    getSession().saveOrUpdate(part);                   
                }
            }
            else{
                getSession().saveOrUpdate(part);
            }
        }
        return new ForwardResolution("/part/view.jsp");   //("/page/Show.action?page="+page);
    }
    
}
