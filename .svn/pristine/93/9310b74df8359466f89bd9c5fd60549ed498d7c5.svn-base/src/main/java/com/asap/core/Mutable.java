package com.asap.core;

public interface Mutable {

	void setValue(Object value);

	Object getValue();
}
