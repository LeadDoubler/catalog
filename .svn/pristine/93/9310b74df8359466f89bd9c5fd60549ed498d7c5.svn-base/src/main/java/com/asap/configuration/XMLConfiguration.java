/*
 * XMLConfiguration.java
 *
 * Created on 15. august 2007, 14:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.configuration;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 *
 * @author mortenandersen
 */
public class XMLConfiguration extends HttpServlet {
    
    
    public void init() throws ServletException {
         //System.out.println("SMTP = "+Configuration.getInstance().getProps().getProperty("smtp"));
        String path = this.getInitParameter("path");
        String realPath = this.getServletContext().getRealPath(path);
        File dir = new File(realPath);
        //System.out.println("Dir = "+dir.getPath());
        for (File file  : dir.listFiles()){
          //   System.out.println("File = "+file.getPath());
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            try {
                DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
                Document doc = docBuilder.parse (file);
                NodeList params = doc.getElementsByTagName("param");
                int totalParam = params.getLength();
                for(int s=0; s < params.getLength() ; s++){
            //        System.out.println("Element = "+params.item(s));
                    Element element = (Element) params.item(s);
                    //System.out.println("Element = "+element.getNodeName());
                    String param =  element.getAttribute("name");  //element.getElementsByTagName("param-name").item(0).getNodeValue();
                    String value = element.getAttribute("value");//element.getElementsByTagName("param-value").item(0).getNodeValue();
                    Configuration.getInstance().getProps().put(param,value);
                }
            } catch (SAXException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            catch (ParserConfigurationException ex) {
                ex.printStackTrace();
            }

        }
        //System.out.println("SMTP = "+Configuration.getInstance().getProps().getProperty("smtp"));
    }
    
    /** Creates a new instance of XMLConfiguration */
    public XMLConfiguration() {
    }

   
    
    
}
