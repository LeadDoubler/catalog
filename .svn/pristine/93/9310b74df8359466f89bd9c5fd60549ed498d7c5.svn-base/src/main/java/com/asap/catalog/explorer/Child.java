/*
 * Child.java
 *
 * Created on 22. februar 2007, 09:55
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.explorer;

import com.asap.catalog.dao.Page;

/**
 *
 * @author mortenandersen
 */
public interface Child {
    
    public String getXml();
    
    public Page getParent(); 
    
    public void setParent(Page page);
    
    
}
