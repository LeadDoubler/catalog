package com.asap.core;

public interface CountedObject {
	// This Id must be unique
	public Long getId();
}
