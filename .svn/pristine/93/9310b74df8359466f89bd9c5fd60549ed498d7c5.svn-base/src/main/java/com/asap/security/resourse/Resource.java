package com.asap.security.resourse;


public interface Resource {

}
