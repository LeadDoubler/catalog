/*
 * BookActionBean.java
 *
 * Created on 13. februar 2007, 13:50
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.book;

import com.asap.catalog.dao.Book;
import com.asap.catalog.dao.Category;
import com.asap.catalog.dao.ProductShopCartItem;
import com.asap.catalog.dao.ShopCart;
import com.asap.catalog.dao.ShopCartItem;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.web.CatalogActionBean;
import java.util.List;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.HandlesEvent;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;

import util.HibernateUtil;

/**
 *
 * @author Jens Rosenberg
 */
public class BookActionBean extends CatalogActionBean {
    private Book book;
    
    public Book getBook (){
        return book;
    }
    
    public void setBook (Book book){
        this.book = book;
    }
    
    public List<Book> getBooks (){
        List list = HibernateUtil.getSessionFactory ().getCurrentSession ().createCriteria (Book.class).list ();
        
        return list;
    }
    
    public Resolution view (){
        return new ForwardResolution ("/book/view.jsp");
    }
    
    public Resolution inlineView(){
        return new ForwardResolution("/book/inlineView.jsp");
    }
    
    @DefaultHandler
    public Resolution list (){
        return new ForwardResolution ("/book/list.jsp");
    }
        
    public Resolution inlineList(){
        return new ForwardResolution("/book/inlineList.jsp");
    }
    
    @Secure (role = Role.MODERATOR)
    public Resolution edit (){
        return new ForwardResolution ("/book/edit.jsp");
    }
    
    @Secure (role = Role.MODERATOR)
    public Resolution save (){
        HibernateUtil.getSessionFactory ().getCurrentSession ().saveOrUpdate (book);
        return new ForwardResolution ("/book/view.jsp");
    }
}
