package com.asap.catalog.dao;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class RequestItem {
	public enum ItemType {

		ITEM(0, "item"), PRODUCT(1, "product"), EMPTY(2, "empty");

		ItemType(int value, String name) {
			this.value = value;
			this.name = name;
		}

		private final int value;

		private final String name;

		public int getValue() {
			return value;
		}

		public String getName() {
			return name;
		}
	}

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "item")
	private ShopCartItem item;

	@Column(name = "count")
	private Long count;

	private ItemType type = ItemType.EMPTY;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ShopCartItem getItem() {
		return item;
	}

	public void setItem(ShopCartItem item) {
		this.type = ItemType.PRODUCT;
		this.item = item;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public ItemType getType() {
		return type;
	}

	public void setType(ItemType type) {
		this.type = type;
	}

	public String getTitle() {
		return item.getName();
	}

	public String getDescription() {
		return item.getDescription();
	}

	public Double getPrice() {
		return item.getPrice();
	}

	public boolean equalsItem(Object item) {
		return this.item.equalsItem(item);
//		return false;
	}

}
