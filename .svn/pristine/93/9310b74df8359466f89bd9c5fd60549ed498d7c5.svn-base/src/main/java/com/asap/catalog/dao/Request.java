package com.asap.catalog.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.asap.catalog.dao.RequestItem.ItemType;

@Entity
public class Request {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date date = new Date();

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "user")
	private User user;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "item_id")
	private List<RequestItem> items = new ArrayList<RequestItem>();

	private Long totalPrice = 0L;
        
        

	private boolean paid;

	private boolean shipped;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<RequestItem> getItems() {
		return items;
	}

	public void setItems(List<RequestItem> items) {
		this.items = items;
	}

	public void addItem(RequestItem item) {
		items.add(item);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}


	public boolean isPaid() {
		return paid;
	}

	public void setPaid(boolean paid) {
		this.paid = paid;
	}

	public boolean isShipped() {
		return shipped;
	}

	public void setShipped(boolean shipped) {
		this.shipped = shipped;
	}

	public Long getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Long totalPrice) {
		this.totalPrice = totalPrice;
	}

	public void addTotalPrice(long addPrice) {
		totalPrice += addPrice;
	}

//	public List<RequestItem> getTerms() {
//		List<RequestItem> result = new ArrayList<RequestItem>();
//		for (RequestItem item : items) {
//			if (item.getType().equals(ItemType.TERM)) {
//				result.add(item);
//			}
//		}
//		return result;
//	}

	public List<RequestItem> getProducts() {
		List<RequestItem> result = new ArrayList<RequestItem>();
		for (RequestItem item : items) {
			if (item.getType().equals(ItemType.PRODUCT)) {
				result.add(item);
			}
		}
		return result;
	}

}
