/*
 * Register.java
 *
 * Created on 5. marts 2007, 09:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.user;

import com.asap.catalog.dao.User;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.web.CatalogActionBean;
import java.util.List;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.DontValidate;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.validation.EmailTypeConverter;
import net.sourceforge.stripes.validation.SimpleError;
import net.sourceforge.stripes.validation.Validate;
import net.sourceforge.stripes.validation.ValidateNestedProperties;
import net.sourceforge.stripes.validation.ValidationErrors;
import net.sourceforge.stripes.validation.ValidationMethod;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import util.HibernateUtil;

/**
 *
 * @author mortenandersen
 */
public class RegisterActionBean extends CatalogActionBean{
    
    @ValidateNestedProperties({            
        @Validate(field = "username", required = true),
        @Validate(field = "firstName", required = true),
        @Validate(field = "lastName", required = true),
        @Validate(field = "email", required = true, converter = EmailTypeConverter.class)
    })
    private User user;
    
    private int low = 0,high = 30;

    private String password1;
    private String password2;
    private String sortBy;
    private Order order;
    
     public List<User> getUsers() {
         Criteria crit = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(User.class).add(Expression.ne("role",Role.GUEST));
         if (getOrder() !=null){
             crit.addOrder(getOrder());
         }
         crit.setFirstResult(low);
         crit.setMaxResults(30);
         return crit.list();
    }
    
    @ValidationMethod
    public void canUserBeAdded(ValidationErrors errors){
        System.out.println("canUserBeAdded - started");
        int uid1=-1;
        int uid2=-2;
        
        if(getUser() != null){
            if(getUser().getId() != null){
                uid1 = getUser().getId().intValue();
            }
        }
        
        if(getContext().getUser() != null){
            if(getContext().getUser().getId() != null){
                uid2 = getContext().getUser().getId().intValue();
            }
        }
            
        if(uid1 != -1 && (uid1 != uid2 || (password1 == null && password2 == null))){
            password1 = getUser().getPassword();
            password2 = password1;
        }
        
        long id = -1;
        if(getUser().getId() != null){
            id = getUser().getId();
        }
        
        List<User> list = getSession().createCriteria(User.class)
            .add(Expression.eq("email",getUser().getEmail()))
            .add(Expression.ne("id",id)).list();
        if (!list.isEmpty()){
            errors.add("user.email",new SimpleError("Bruger med angivet email findes i forvejen."));
        }
        
        list = getSession().createCriteria(User.class)
            .add(Expression.eq("username",getUser().getUsername()))
            .add(Expression.ne("id",id)).list();
        if (!list.isEmpty()){
             errors.add("user.username",new SimpleError("Bruger med angivet brugernavn findes i forvejen."));
        }
        
        if(password1 == null || password1 == ""){
            errors.add("password1",new SimpleError("Udfyld venligst dette felt"));
        }
        if(password2 == null || password2 == ""){
            errors.add("password2",new SimpleError("Udfyld venligst dette felt"));
        }
        else if ( !password1.equals( password2 ) ){
            errors.add("password2",new SimpleError("De to passwords skal matche"));
        }
    }
        
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Resolution saveExisting() {
        System.out.println("Adding user: "+user.getUsername());
        getUser().setPassword(password1);
        HibernateUtil.getSessionFactory().getCurrentSession().saveOrUpdate(getUser());
        return new RedirectResolution("");
    }
    
    public Resolution save() {
        System.out.println("Adding user: "+user.getUsername());
        getUser().setPassword(password1);
        HibernateUtil.getSessionFactory().getCurrentSession().saveOrUpdate(getUser());
        return new RedirectResolution("/user/registered.jsp");
    }

    @DefaultHandler
    @DontValidate
    public Resolution init() {
        if(getUser() != null && getContext().getUser() != null){
            if(getUser().getId().intValue() != getContext().getUser().getId().intValue()
                && getUser().getRole().getValue() > getContext().getUser().getRole().getValue()){
                return new RedirectResolution("/user/Login.action");
            }
        }
        return new ForwardResolution("/user/register.jsp");
    }

    
    @DontValidate
    @Secure(role=Role.ADMINISTRATOR,currentUser=true)
    public Resolution edit() {
        if(getUser() != null && getContext().getUser() != null){
            if(getUser().getId().intValue() != getContext().getUser().getId().intValue()
                && getUser().getRole().getValue() > getContext().getUser().getRole().getValue()){
                return new RedirectResolution("/user/Login.action");
            }
        }
        return new ForwardResolution("/user/edit.jsp");
    }
    
    
    @Secure(role = Role.ADMINISTRATOR)
    @DontValidate
    public Resolution list() {
        return new ForwardResolution("/user/list.jsp");
    }
 
    @Secure(role = Role.ADMINISTRATOR,currentUser=true)
    @DontValidate
    public Resolution view() {
        return new ForwardResolution("/user/view.jsp");
    }
    
    @Secure(role = Role.ADMINISTRATOR)
    @DontValidate
    public Resolution delete() {
         if(getUser().getRole().getValue() > getContext().getUser().getRole().getValue()){
            return new RedirectResolution("/user/Login.action");
        }
        getUser().setRole(Role.GUEST);
        getSession().saveOrUpdate(user);
        //getSession().delete(getUser());
        return new ForwardResolution("/user/list.jsp");
    }
    
    @DontValidate
    public String getPassword1() {
        return password1;
    }

    @DontValidate
    public void setPassword1(String password1) {
        this.password1 = password1;
    }
    
    @DontValidate
    public String getPassword2() {
        return password2;
    }

    @DontValidate
    public void setPassword2(String password2) {
        this.password2 = password2;
    }
    
    @DontValidate
    public Resolution forgotPassword(){
        return new ForwardResolution("/user/forgotpass.jsp" );
    }

    public int getHigh() {
        return high;
    }

    public void setHigh(int high) {
        this.high = high;
    }

    public int getLow() {
        return low;
    }

    public void setLow(int low) {
        this.low = low;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

}
