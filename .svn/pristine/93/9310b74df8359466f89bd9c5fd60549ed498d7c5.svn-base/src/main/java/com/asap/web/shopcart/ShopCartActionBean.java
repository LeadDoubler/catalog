package com.asap.web.shopcart;

import com.asap.catalog.dao.Customer;
import com.asap.catalog.dao.ShopCartOrder;
import com.asap.catalog.dao.User;
import com.asap.catalog.dao.manager.UserManager;
import com.asap.catalog.enums.ShopCartOrderStatus;
import com.asap.security.Role;
import com.asap.security.Secure;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.mail.internet.AddressException;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.DontValidate;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.HandlesEvent;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.validation.EmailTypeConverter;
import net.sourceforge.stripes.validation.Validate;
import net.sourceforge.stripes.validation.ValidateNestedProperties;
import org.hibernate.criterion.Restrictions;
import org.mortena.mail.HTMLMailController;
import util.HibernateUtil;

import com.asap.catalog.dao.Request;
import com.asap.catalog.dao.RequestItem;
import com.asap.catalog.dao.ShopCart;
import com.asap.catalog.dao.ShopCartItem;
import com.asap.core.number.MutableInteger;
import com.asap.util.HTMLMailSender;
import com.asap.web.CatalogActionBean;

import freemarker.template.Configuration;
import freemarker.template.Template;


public class ShopCartActionBean extends CatalogActionBean {
    
    private ShopCart shopcart;
    private ShopCartItem item;
    private ShopCartOrder order;
    
    @ValidateNestedProperties({            
        @Validate(field = "name", required = true),
        @Validate(field = "address", required = true),
        @Validate(field = "zip", required = true),
        @Validate(field = "city", required = true),
        @Validate(field = "phone", required = true),
        @Validate(field = "email", required = true, converter = EmailTypeConverter.class)
    })
    private Customer customer;
    
    @DontValidate
    public ShopCart getShopcart() {
        if (shopcart == null)
            this.shopcart = getContext().getShopCart();
        return shopcart;
    }
    
    @DontValidate
    public Resolution continueShopping() {
        return new RedirectResolution("/product/Product.action?list");
    }
    
    @DontValidate
    public void setShopcart(ShopCart shopcart) {
        this.shopcart = shopcart;
    }
    
    @DefaultHandler
    @DontValidate
    public Resolution view() {
        this.shopcart = getContext().getShopCart();
        return new ForwardResolution("/shopcart/view.jsp");
    }
    
    @DontValidate
    public Resolution inlineView() {
        this.shopcart = getContext().getShopCart();
        return new ForwardResolution("/shopcart/inlineView.jsp");
    }
    
    @DontValidate
    public Resolution smallView() {
        this.shopcart = getContext().getShopCart();
        return new ForwardResolution("/shopcart/smallView.jsp");
    }
    
    @DontValidate
    public Resolution listOrders(){
        return new ForwardResolution("/shopcart/listOrders.jsp");
    }
    
    @DontValidate
    public Resolution viewOrder() {
        return new ForwardResolution("/shopcart/viewOrder.jsp");
    }
    
    @DontValidate
    public Resolution deleteItem() {
        if(item != null){
            getSession().delete(item);
        }
        return new ForwardResolution("/shopcart/view.jsp");
    }
    
    public Resolution save() {
        System.out.println("Saving shopping cart - order");
        this.shopcart = getContext().getShopCart();
        if(customer.getCompany() == null){
            customer.setCompany("(ikke angivet)");
        }
        if(customer.getEan() == null) {
            customer.setEan("(ikke angivet)");
        }                
        if (getOrder().getLocation().equals("Deliver")){
            getOrder().setDeliver(true);
        }
        else{
            getOrder().setDeliver(false);
        }
        getOrder().setCustomer(customer);
        getOrder().setShopcart(shopcart);
        getOrder().setDate(new Date());
        getSession().saveOrUpdate(customer);
        getSession().saveOrUpdate(shopcart);
        
        //getContext().setShopCart(null);
        getSession().saveOrUpdate(getOrder());
        getContext().getRequest().getSession().setAttribute("order", getOrder());
        return new ForwardResolution("/shopcart/payment.jsp");
        
    }
        
    public Resolution approve() {
        this.shopcart = getContext().getShopCart();
        
        if(customer.getCompany() == null) customer.setCompany("(ikke angivet)");
        if(customer.getEan() == null) customer.setEan("(ikke angivet)");
        
        //order = new ShopCartOrder();
        //setOrder((ShopCartOrder) getContext().getRequest().getSession().getAttribute("order"));
        getOrder().setStatus(ShopCartOrderStatus.NEW);
        
        order.setCustomer(customer);
        order.setShopcart(shopcart);
        order.setDate(new Date());
        
        getSession().saveOrUpdate(customer);
        getSession().saveOrUpdate(shopcart);
        
        getContext().setShopCart(null);
        getSession().saveOrUpdate(getOrder());
        
        
        HTMLMailSender sender = new HTMLMailSender();
        try {
           
            sender.setToAddress(customer.getEmail());
            
            sender.setFromAddress("No-reply@familiediner.dk");
            sender.setSubject("Kvittering fra familiediner.dk");
            Map dataModel = new HashMap();
            //Request request = fillRequest();
            dataModel.put("order", getOrder());
            dataModel.put("items",getOrder().getShopcart().getItems());
            dataModel.put("shopcart", getOrder().getShopcart() ) ;
            dataModel.put("headerFile", "shopheader.ftl");
            dataModel.put("footerFile", "shopfooter.ftl");
	// resolve result of Template
            Writer writer = new StringWriter();
             Configuration cfg = new Configuration();
            cfg.setServletContextForTemplateLoading(getContext().getServletContext(), "template");
            cfg.setEncoding(getContext().getLocale(),"utf-8");
            Template template = cfg.getTemplate("shop.ftl");
            String val = template.getOutputEncoding();
            template.setEncoding("Cp1252");
            template.setOutputEncoding("Cp1252");
            template.process(dataModel, writer);
            String messageText = writer.toString();
            messageText = sender.replaceDanishLetters(messageText);
            sender.setMessageText(messageText);
            sender.sendMail();
            sender.setToAddress("info@familiediner.dk");
            sender.setSubject("Bestilling gennemf�rt");
            sender.sendMail();
        } catch(Exception e){
            e.printStackTrace();
        }
        
        // Send out mail
        try {
            //sendEmail();           
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return new ForwardResolution("/shopcart/viewOrder.jsp");
    }

    private void sendEmail() throws IOException, AddressException {
        Configuration cfg = new Configuration();
        cfg.setServletContextForTemplateLoading(
                getContext().getServletContext(), "template");
        cfg.setEncoding(getContext().getLocale(),"utf-8");
        
        Map root = new HashMap();
        //Request request = fillRequest();
        root.put("order", getOrder());
        root.put("items",getOrder().getShopcart().getItems());
        root.put("shopcart", getOrder().getShopcart() ) ;
        String context = "http://"
				//+ getContext().getRequest().getLocalName() + ":"
				//+ getContext().getRequest().getLocalPort()
				+ getContext().getRequest().getContextPath() + "/";

        root.put("context", context);
        
        Template t = cfg.getTemplate("shop.ftl");
        t.setLocale(new Locale("da_DK"));
        
        // To customer
        HTMLMailSender htmlMailSender = new HTMLMailSender();
        System.out.println("Template = "+t);
        htmlMailSender.setTemplate(t);
        htmlMailSender.setDataModel(root);
        htmlMailSender.setHeaderFile("shopheader.ftl");
        htmlMailSender.setFooterFile("shopfooter.ftl");
        htmlMailSender.setFromAddress("no-reply@familiediner.dk");
        htmlMailSender.setToAddress(customer.getEmail());
        htmlMailSender.setSubject("Din kvittering");

        htmlMailSender.sendMail();
    }
    
    @DontValidate
    public Resolution editCustomer() {
        if(customer != null && customer.getUser() != null){
            if(customer.getUser().getFullname() != null) customer.setName(customer.getUser().getFullname());
            if(customer.getUser().getPhone() != null) customer.setPhone(customer.getUser().getPhone());
            if(customer.getUser().getEmail() != null){customer.setEmail(customer.getUser().getEmail());}
            if(customer.getUser().getPostalCode() != null){customer.setZip(customer.getUser().getPostalCode());}
            if(customer.getUser().getStreet() != null){ customer.setAddress(customer.getUser().getStreet());}
            if(customer.getUser().getCity() != null){customer.setCity(customer.getUser().getCity());}
            if(customer.getUser().getCountry() != null){customer.setCountry(customer.getUser().getCountry());}
            if(customer.getUser().getCvr() != null){customer.setCvr(customer.getUser().getCvr());}
        }
        return new ForwardResolution("/shopcart/editCustomer.jsp");
    }
    
    @DontValidate
    @Secure(role = Role.CORRECTOR)
    public Resolution markOrderAsTreated(){
        if(getOrder() != null){
            getOrder().setStatus(ShopCartOrderStatus.TREATED);
            getSession().saveOrUpdate(getOrder());
        }
        return new ForwardResolution("/shopcart/listOrdersWithStatus.jsp");
    }
    
    @DontValidate
    @Secure(role = Role.CORRECTOR)
    public Resolution listOrdersWithStatus(){
        return new ForwardResolution("/shopcart/listOrdersWithStatus.jsp");
    }
    
    public ShopCartItem getItem() {
            return item;
    }

    public void setItem(ShopCartItem item) {
            this.item = item;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public ShopCartOrder getOrder() {
        return order;
    }

    public void setOrder(ShopCartOrder order) {
        this.order = order;
    }
}
