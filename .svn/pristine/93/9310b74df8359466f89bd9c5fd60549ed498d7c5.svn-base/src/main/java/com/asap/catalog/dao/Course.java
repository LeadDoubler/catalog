package com.asap.catalog.dao;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.asap.catalog.enums.CourseComplexity;
import com.asap.catalog.enums.EntranceLevel;
import org.hibernate.annotations.Type;

@Entity
@DiscriminatorValue("COURSE")
public class Course extends Product {

    private Integer duration;

    private EntranceLevel entranceLevel;

    private CourseComplexity complexity;

    @Type(type = "text")
    private String extrainfo;

    public CourseComplexity getComplexity() {
            return complexity;
    }

    public void setComplexity(CourseComplexity complexity) {
            this.complexity = complexity;
    }

    public Integer getDuration() {
            return duration;
    }

    public void setDuration(Integer duration) {
            this.duration = duration;
    }

    public EntranceLevel getEntranceLevel() {
            return entranceLevel;
    }

    public void setEntranceLevel(EntranceLevel entranceLevel) {
            this.entranceLevel = entranceLevel;
    }

    public String getType(){
        return "Course";
    }

    public Long getId(){
        return id;
    }

    public void setId(Long id){
        this.id = id;
    }

    public String getExtrainfo() {
        return extrainfo;
    }

    public void setExtrainfo(String extrainfo) {
        this.extrainfo = extrainfo;
    }
}  
