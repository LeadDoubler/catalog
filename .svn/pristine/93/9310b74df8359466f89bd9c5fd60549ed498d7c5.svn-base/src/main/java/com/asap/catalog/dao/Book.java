package com.asap.catalog.dao;

import java.util.Date;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import org.hibernate.annotations.Type;

@Entity
@DiscriminatorValue("BOOK")
public class Book extends Product {

    private String author;

    private String isbn; 

    private String date;
    
    public String getAuthor() {
            return author;
    }

    public void setIsbn(String isbn) {
            this.isbn = isbn;
    }

    public String getIsbn() {
            return isbn;
    }

    public void setAuthor(String author) {
            this.author = author;
    }

    public String getDate() {
            return date;
    }

    public void setDate(String date) {
            this.date = date;
    }

    public String getXml(){        
        String s = "<book><id>" + getId() + "</id><title>"+title+"</title></book>";
        return s;    
    }
        
    public String getType(){
        return "Book";
    }
}
