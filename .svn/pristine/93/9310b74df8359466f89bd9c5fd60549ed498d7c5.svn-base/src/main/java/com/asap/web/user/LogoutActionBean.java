package com.asap.web.user;

import com.asap.web.*;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.UrlBinding;

public class LogoutActionBean extends CatalogActionBean {
	@DefaultHandler
	public Resolution logout() throws Exception {
		getContext().logout();
		return new RedirectResolution("/");
	}
}
