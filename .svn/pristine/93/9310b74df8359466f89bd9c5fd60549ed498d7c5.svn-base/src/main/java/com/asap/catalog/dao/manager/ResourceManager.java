package com.asap.catalog.dao.manager;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import net.sourceforge.stripes.action.UrlBinding;
import net.sourceforge.stripes.controller.ActionClassCache;

import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.security.resourse.ResourceRepository;
import com.asap.security.resourse.SecurityResource;
import com.asap.security.resourse.XStreamResourceRepository;
//import com.sun.corba.se.spi.activation.Repository;

public class ResourceManager {
	private static ResourceRepository repository = new XStreamResourceRepository();

	private static Map<String, SecurityResource> resources = new HashMap<String, SecurityResource>();

	public static Map<String, SecurityResource> getResourceConfiguration() {
		ResourceManager.resources = ResourceManager.repository.getResources();
		if (resources == null)
			resources = new HashMap<String, SecurityResource>();
		Set set = ActionClassCache.getInstance().getActionBeanClasses();
		Iterator<Class> iterator = set.iterator();
		while (iterator.hasNext()) {
			Class con = (Class) iterator.next();
			UrlBinding urlBinding = (UrlBinding) con
					.getAnnotation(UrlBinding.class);
			if (urlBinding == null) {
				Secure secure = (Secure) con.getAnnotation(Secure.class);
				if (secure != null) {
					SecurityResource sr = resources.get(con.getCanonicalName());
					if (sr == null) {
						sr = new SecurityResource("", Role.GUEST, secure.role());
						resources.put(con.getCanonicalName(), sr);
					} else {
						sr.setUrl("");
						sr.setDefaultRole(secure.role());
					}
				} else {
					SecurityResource sr = resources.get(con.getCanonicalName());
					if (sr == null) {
						sr = new SecurityResource("", Role.GUEST, Role.GUEST);
						resources.put(con.getCanonicalName(), sr);
					} else {
						sr.setUrl("");
						sr.setDefaultRole(Role.GUEST);
					}
				}
			} else {
				Secure secure = (Secure) con.getAnnotation(Secure.class);
				if (secure != null) {
					SecurityResource sr = resources.get(con.getCanonicalName());
					if (sr == null) {
						sr = new SecurityResource(urlBinding.value(),
								Role.GUEST, secure.role());
						resources.put(con.getCanonicalName(), sr);
					} else {
						sr.setUrl(urlBinding.value());
						sr.setDefaultRole(secure.role());
					}
				} else {
					SecurityResource sr = resources.get(con.getCanonicalName());
					if (sr == null) {
						sr = new SecurityResource(urlBinding.value(),
								Role.GUEST, Role.GUEST);
						resources.put(con.getCanonicalName(), sr);
					} else {
						sr.setUrl(urlBinding.value());
						sr.setDefaultRole(Role.GUEST);
					}
				}
			}
		}
		return resources;
	}

	public static void saveResourceConfiguration(
			Map<String, SecurityResource> resources) {
		ResourceManager.repository.saveResources(resources);
		ResourceManager.resources = resources;

	}

}
