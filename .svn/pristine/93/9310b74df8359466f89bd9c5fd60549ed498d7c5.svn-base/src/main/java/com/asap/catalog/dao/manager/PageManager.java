/*
 * PageManager.java
 *
 * Created on 15. marts 2007, 11:35
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao.manager;

import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.Part;
import com.asap.catalog.dao.manager.Manager;
import com.asap.catalog.enums.Language;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;

import util.HibernateUtil;

import com.asap.catalog.dao.Page;
import com.asap.catalog.enums.Language;

/**
 * 
 * @author mortenandersen
 */
public class PageManager implements Manager {

    String text;
    private String language;
    
    
    public Collection getResults() {
        String search = "%"+getText()+"%";
        Criteria crit = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Page.class);
        crit.add(
            Expression.or(
                Expression.like("title",search)
                ,
               Expression.like("content",search)
            )                
        ).add(Expression.or(Expression.isNull("deactivated"),Expression.ne("deactivated","yes")));
        //crit.createCriteria("parts").add(Expression.like("content",search));
        /*if ( getLanguage() != null) {     
            //crit.add( Expression.sql( "this_.language = '"+getLanguage()+"'" ));
            crit.add( Expression.like( "language" , Language.valueOf( getLanguage() ) ) );
        }*/
       
        Set pages = new LinkedHashSet(crit.list());
        System.out.println("pages.size = "+pages.size());
        Criteria partCrit = HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Part.class);
        partCrit.add(Expression.like("content",search));
        List<Part> parts = partCrit.list();
        for (Part part : parts){
            if (part.getPage().getDeactivated() != null && part.getPage().getDeactivated().equals("yes")){
                
            }
            else{
                pages.add(part.getPage());
            }
        }
        System.out.println("pages.size = "+pages.size());
        return pages;
    }

	public List<Page> getAllPages() {
		List<Page> pages = HibernateUtil.getSessionFactory()
				.getCurrentSession().createCriteria(Page.class).list();
		return pages;
	}
        
        public List<Page> getDeactivatedPages() {
            List<Page> pages = HibernateUtil.getSessionFactory()
				.getCurrentSession().createCriteria(Page.class).add(Expression.eq("deactivated","yes")).list();
            return pages;                    
        }
        
        public List<Page> getHiddenPages() {
            List<Page> pages = HibernateUtil.getSessionFactory()
				.getCurrentSession().createCriteria(Page.class).add(Expression.eq("hide","yes")).list();
            return pages;                    
        }


	public List<Page> getSearchResults() throws ParseException {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		FullTextSession fullTextSession = Search.createFullTextSession(session);

		org.apache.lucene.queryParser.QueryParser parser = new QueryParser(
				"title", new StopAnalyzer());

		org.apache.lucene.search.Query luceneQuery = parser
				.parse("title:blabla");
		org.hibernate.Query fullTextQuery = fullTextSession
				.createFullTextQuery(luceneQuery, Page.class);

		List result = fullTextQuery.list();
		return result;
	}
/*
	public Collection getResults() {
		String search = "%" + getText() + "%";
		Criteria crit = HibernateUtil.getSessionFactory().getCurrentSession()
				.createCriteria(Page.class);
		crit.add(Expression.or(Expression.like("title", search), Expression
				.like("content", search)));
		crit.createCriteria("parts").add(Expression.like("content", search));
		if (getLanguage() != null) {
			// crit.add( Expression.sql( "this_.language = '"+getLanguage()+"'"
			// ));
			crit.add(Expression.like("language", Language
					.valueOf(getLanguage())));
		}
		return new LinkedHashSet(crit.list());
	}
*/
	public String getUrl() {
		return "page";
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String lang) {
		this.language = lang;
	}

	public Page getDanishLandingPage() {
		List<Page> pages = HibernateUtil.getSessionFactory()
				.getCurrentSession().createCriteria(Page.class).add(
						Expression.eq("urlMap", "*")).add(
						Expression.eq("language", Language.DANISH))
				.setMaxResults(1).list();

		if (!pages.isEmpty()) {
			return pages.get(0);
		}
		return null;
	}

	public Page getEnglishLandingPage() {
		List<Page> pages = HibernateUtil.getSessionFactory()
				.getCurrentSession().createCriteria(Page.class).add(
						Expression.eq("urlMap", "*")).add(
						Expression.eq("language", Language.ENGLISH))
				.setMaxResults(1).list();

		if (!pages.isEmpty()) {
			return pages.get(0);
		}
		return null;
	}

    public String getText() {
        return text;
    }
}
