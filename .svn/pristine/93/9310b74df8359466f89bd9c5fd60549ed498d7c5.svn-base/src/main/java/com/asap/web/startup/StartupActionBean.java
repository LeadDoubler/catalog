/*
 * StartupActionBean.java
 *
 * Created on 4. april 2007, 19:03
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.startup;

import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.User;
import com.asap.catalog.dao.manager.PageManager;
import com.asap.catalog.enums.Language;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.web.CatalogActionBean;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.config.Configuration;
import net.sourceforge.stripes.localization.DefaultLocalePicker;
import net.sourceforge.stripes.localization.LocalePicker;
import org.apache.taglibs.standard.tag.el.fmt.SetLocaleTag;
import org.hibernate.criterion.Expression;
import org.mortena.stripes.conf.StripesLocalePicker;
import org.quartz.SchedulerException;
import util.HibernateUtil;

/**
 *
 * @author Jens Rosenberg
 */
public class StartupActionBean extends CatalogActionBean{
    
    /** Creates a new instance of StartupActionBean */
    @DefaultHandler
    public Resolution StartupActionBean() {
        
        /* Writing enums system variables */
        /*Language[] langs = Language.values();
        for(int i=0;i<langs.length;i++){
            this.getContext().getRequest().setAttribute(""+langs[i],langs[i].getValue());
        }
        
        Role[] roles = Role.values();
        for(int i=0;i<roles.length;i++){
             this.getContext().getRequest().setAttribute(""+roles[i],roles[i].getValue());
        }
        
        BannerType[] bt = BannerType.values();
        for(int i=0;i<bt.length;i++){
             this.getContext().getRequest().setAttribute(""+bt[i],bt[i].getValue());
        }*/
        
        /* Securing initial administrator */
        List<User> users = HibernateUtil.getSessionFactory().getCurrentSession()
            .createCriteria(User.class).add(Expression.eq("role",Role.ADMINISTRATOR)).setMaxResults(1).list();
        if(users.isEmpty()){
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin");
            admin.setFirstName("Default");
            admin.setLastName("administrator");
            admin.setRole(Role.ADMINISTRATOR);
            HibernateUtil.getSessionFactory().getCurrentSession().save(admin);
        }
        
        /* Creating language pages */
        List<Page> pages = HibernateUtil.getSessionFactory().getCurrentSession()
            .createCriteria(Page.class).setMaxResults(1).list();
        if(pages.isEmpty()){
            Page page = new Page();
            page.setLanguage(Language.DANISH);
            page.setTitle("Dansk CMS root");
            page.setUrlMap("*");
            page.setContent("<p><strong>CMS rod (Dansk)</strong></p><p>Indholdet af denne side bliver aldrig vist, men alle andre sider nedarver denne sides:</p><ul><li>Banner</li><li>Sidekasser</li></ul><p>hvis intet andet er specificeret. S&aring;fremt disse &aelig;ndres nedarves istedet dette indhold til underst&aring;ende sider.</p><p>&nbsp;</p> <p>Denne side er samtidig den indledende startside. S&aring;fremt denne sides viser som startside, skal der s&aelig;ttes et * ved &quot;UrlMap&quot; under &quot;metatags&quot; under den &oslash;nskede startside.</p><p>&nbsp;</p>");
            HibernateUtil.getSessionFactory().getCurrentSession().save(page);
            
            page = new Page();
            page.setLanguage(Language.ENGLISH);
            page.setTitle("English CMS root");
            page.setUrlMap("*");
            page.setContent("<p><strong>CMS rod (Engelsk)</strong></p><p>Indholdet af denne side bliver aldrig vist, men alle andre sider nedarver denne sides:</p><ul><li>Banner</li><li>Sidekasser</li></ul><p>hvis intet andet er specificeret. S&aring;fremt disse &aelig;ndres nedarves istedet dette indhold til underst&aring;ende sider.</p><p>&nbsp;</p> <p>Denne side er samtidig den indledende startside. S&aring;fremt denne sides viser som startside, skal der s&aelig;ttes et * ved &quot;UrlMap&quot; under &quot;metatags&quot; under den &oslash;nskede startside.</p><p>&nbsp;</p>");
            HibernateUtil.getSessionFactory().getCurrentSession().save(page);
            
            return new ForwardResolution("/user/Login.action");
        }
        
        // Finding default landing page
        String lang = getContext().getRequest().getLocale().getLanguage();
        if(lang.equals(Language.ENGLISH.getCode())){
            pages = HibernateUtil.getSessionFactory().getCurrentSession()
                .createCriteria(Page.class).add(Expression.eq("urlMap","*"))
                .add(Expression.eq("language",Language.ENGLISH)).setMaxResults(1).list();
        }else{
            pages = HibernateUtil.getSessionFactory().getCurrentSession()
                .createCriteria(Page.class).add(Expression.eq("urlMap","*"))
                .add(Expression.eq("language",Language.DANISH)).setMaxResults(1).list();
        }
        
        if(!pages.isEmpty())
            return new ForwardResolution("/page/Show.action?page="+pages.get(0).getId());
        else
            return new ForwardResolution("/page/Show.action");
    }
    
    @Secure(role=Role.USER)
    public Resolution home(){
        return new ForwardResolution("/user/UserLoggedIn.jsp");
    }
    
    public Resolution dansk(){
        Page page = (Page)HibernateUtil.getSessionFactory().getCurrentSession()
                .createCriteria(Page.class).add(Expression.eq("urlMap","*"))
                .add(Expression.eq("language",Language.DANISH)).setMaxResults(1).uniqueResult();
        return new RedirectResolution("/page/"+page.getId().intValue());
    }
    
    public Resolution english(){
        Page page = (Page)HibernateUtil.getSessionFactory().getCurrentSession()
                .createCriteria(Page.class).add(Expression.eq("urlMap","*"))
                .add(Expression.eq("language",Language.ENGLISH)).setMaxResults(1).uniqueResult();
        if (page == null){
           // System.out.println("Page set as the first");
            page = (Page)HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Page.class).list().get(0);
        }
        return new RedirectResolution("/page/"+page.getId().intValue());
    }
    
    
}
