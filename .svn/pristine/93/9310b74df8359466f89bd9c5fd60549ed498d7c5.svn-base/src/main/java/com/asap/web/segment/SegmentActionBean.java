package com.asap.web.segment;

import com.asap.catalog.dao.Category;
import com.asap.security.Role;
import com.asap.security.Secure;
import net.sourceforge.stripes.action.UrlBinding;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.ForwardResolution;
import com.asap.web.CatalogActionBean;
import com.asap.catalog.dao.Page;

import java.util.List;

import org.hibernate.criterion.Expression;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-02-20
 * Time: 14:19:30
 * To change this template use File | Settings | File Templates.
 */
public class SegmentActionBean extends CatalogActionBean {

    @Secure(role = Role.MODERATOR)
    public Resolution editMenu(){
        return new ForwardResolution("/treeMenu/menu.jsp");
    }

    public String getXml(){
        List<Page> pages = getSession().createCriteria(Page.class).add(Expression.isNull("parent")).list();
        StringBuffer sb = new StringBuffer();
        if (pages!=null && pages.size()>0){
            Page front = pages.get(0);
            front.initializeChildren();
            return pages.get(0).getXml();
        }
       /* Segment segment = new Segment();
        if (pages!=null && pages.size()>0){
            segment.setPage(pages.get(0));
        }*/
        return sb.toString();

    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution editCategories(){
        return new ForwardResolution("/treeMenu/category.jsp");
    }
}
    