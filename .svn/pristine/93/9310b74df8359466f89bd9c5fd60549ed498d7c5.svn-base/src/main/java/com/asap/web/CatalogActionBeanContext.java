package com.asap.web;

import com.asap.catalog.dao.Page;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.controller.StripesConstants;

import com.asap.catalog.dao.ShopCart;
import com.asap.catalog.dao.User;
import java.util.List;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;

/**
 * ActionBeanContext subclass for the Bugzooky application that manages where
 * values like the logged in user are stored.
 * 
 * @author Tim Fennell
 */
public class CatalogActionBeanContext extends ActionBeanContext {

	class ShopCartListener implements HttpSessionBindingListener {
		private ShopCart shopCart;

		public ShopCartListener(ShopCart shopCart) {
			super();
			this.shopCart = shopCart;
		}

		public void valueBound(HttpSessionBindingEvent evt) {
		}

		public void valueUnbound(HttpSessionBindingEvent evt) {
			shopCart.invalidate();
		}

	}

	/** Gets the currently logged in user, or null if no-one is logged in. */
	public User getUser() {
		Object object = getRequest().getSession().getAttribute("user");
		if (object != null) {
			if (object instanceof User) {
				return (User) object;
			}
		}
		return null;
	}

	/** Sets the currently logged in user. */
	public void setUser(User currentUser) {
		getRequest().getSession().setAttribute("user", currentUser);
	}

	/**
	 * Gets the currently logged in users shopcart, or null if no-one is logged
	 * in or havn't shopcart.
	 */
	public ShopCart getShopCart() {
		Object object = getRequest().getSession().getAttribute("shopcart");
		if (object != null) {
			if (object instanceof ShopCart) {
				return (ShopCart) object;
			}
		} else {
			ShopCart shopCart = new ShopCart();
			setShopCart(shopCart);

			getRequest().getSession().setAttribute("listener",
					new ShopCartListener(shopCart));

			return shopCart;
		}
		return null;
	}
        
         /**
         *Gets page from session if it's there. Else the default page is loaded.
         **/
        public Page getPage(){
            Object object = getRequest().getSession().getAttribute("page");
            if (object != null) {
                    if (object instanceof Page) {
                            return (Page) object;
                    }
            } else {
                List<Page> listOfPages = HibernateUtil.getSessionFactory().getCurrentSession().
                        createCriteria(Page.class).
                        add(Expression.isNull("parent")).list();
                for(Page page : listOfPages){
                    return page;
                }
            }
            return null;
        }
       

	/** Sets the currently logged in users shopcart. */
	public void setShopCart(ShopCart shopCart) {
		// if ()
		getRequest().getSession().setAttribute("shopcart", shopCart);
	}

	public void removeShopCart() {
		getRequest().getSession().setAttribute("shopcart", new ShopCart());
	}

	/** Logs the user out by invalidating the session. */
	public void logout() {
            getRequest().getSession().setAttribute("user",null);
		getRequest().getSession().invalidate();
	}

	/**
	 * <p>
	 * Returns a resolution that can be used to return the user to the page from
	 * which they submitted they current request. Most useful in situations
	 * where a user-correctable error has occurred that was too difficult or
	 * expensive to check at validation time. In that case an ActionBean can
	 * call setValidationErrors() and then return the resolution provided by
	 * this method.
	 * </p>
	 * 
	 * @return Resolution a resolution that will forward the user to the page
	 *         they came from
	 * @throws IllegalStateException
	 *             if the information required to construct a source page
	 *             resolution cannot be found in the request.
	 * 
	 */
	@Override
	public Resolution getSourcePageResolution() {
		//System.out.println("GetSourcePageResolution");
		String sourcePage = getRequest().getParameter(
				StripesConstants.URL_KEY_SOURCE_PAGE);

		if (sourcePage == null) {
			//System.out.println("No source page");
			return new ForwardResolution("/user/UserLoggedIn.jsp");
		} else {
			//System.out.println(sourcePage);
			return new ForwardResolution(sourcePage);
		}
	}

}