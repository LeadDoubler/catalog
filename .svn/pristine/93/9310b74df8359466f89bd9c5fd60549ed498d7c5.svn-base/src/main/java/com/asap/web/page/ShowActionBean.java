/*
 * ShowActionBean.java
 *
 * Created on 21. februar 2007, 11:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.page;

import com.asap.catalog.dao.Page;
import com.asap.catalog.dao.manager.PageManager;
import com.asap.catalog.enums.BannerType;
import com.asap.web.CatalogActionBean;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.StreamingResolution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Expression;

/**
 * @author mortenandersen
 */
public class ShowActionBean extends CatalogActionBean{
    Log log = LogFactory.getLog(ShowActionBean.class);
    
    private String url;
    Page page;
    
    public Resolution inline(){
       // System.out.println("inline started...");
        if (page.getContentforward()!=null && page.getContentforward().length()>0){
          //  System.out.println("Forwards to:"+page.getContentforward());
            return new RedirectResolution(page.getContentforward());
        }       
        return go("/page/inlineView.jsp");
    }
    
    @DefaultHandler
    public Resolution view() {
        String forward = "/page/showPage.jsp";
        if ("front".equals(page.getPageType())){
            forward = "/page/Front.jsp";
        }
        return go(forward);
    }

    private Resolution go(final String forward) throws HibernateException {
        Resolution fr = new ForwardResolution(forward);
        log.warn("SHOWING PAGE");
        if (page == null){
            Page pageToShow = (Page) getSession().createCriteria(Page.class).add(Expression.like("url",url)).uniqueResult();
            if (pageToShow == null){
                pageToShow = new PageManager().getDanishLandingPage();
                //pageToShow = (Page) getSession().load( Page.class , new Long(1) ) ;
                /*pageToShow = (Page)HibernateUtil.getSessionFactory().getCurrentSession()
                .createCriteria(Page.class).add(Expression.eq("urlMap","*"))
                .add(Expression.eq("language",Language.DANISH)).setMaxResults(1).uniqueResult();*/
                if (pageToShow == null){
                    pageToShow = new PageManager().getAllPages().get(0);
                }
                
            }
            setPage(pageToShow);
        }
        //System.out.println("Setting session.page = "+page);
        this.getContext().getRequest().getSession().setAttribute("page",page);
        this.getContext().getRequest().setAttribute("page",page);
        if (page != null && page.getForward()!= null && page.getForward().length()>0){
            if (page.getForward().endsWith(".jsp")){ 
          //      System.out.println("forward is not null - Going by ForwardResolution to: "+page.getForward());
                fr = new ForwardResolution(page.getForward());
            }  
            else{
            //    System.out.println("Going by RedirectResolution to: "+page.getForward());                
                fr =  new RedirectResolution(page.getForward());
            }
        }
        else{
            //System.out.println("Going by ForwardResolution to: /page/showPage.jsp");   
        }
        return fr;
    }
        
    /** Creates a new instance of ShowActionBean */
    public ShowActionBean() {
        log.info("Starting up SHOWACTIONBEAN");
    }
    
    public String getUrl() {
        return url;
    }
    
    public void setUrl(String url) {
        this.url = url;
    }
    
    public Page getPage() {
        return page;
    }
    
    public void setPage(Page page) {
        this.page = page;
    }
    
   public Resolution getEnheritedBanner () {
        // Finding first page object in hirachi with BannerType != NONE
        Page image_page = page;
        while((image_page.getBanner_type() == BannerType.NONE) && (image_page.getParent() != null)){
            image_page = image_page.getParent();
        }
            
        InputStream reader = new ByteArrayInputStream (image_page.getPicture_binary ());
        return new StreamingResolution (image_page.getBanner_type().name(), reader);
    }
}
