/*
 * Part.java
 *
 * Created on 6. marts 2007, 12:00
 *
 *This class holds a part of the content of the page. It's a placeholder for a 
 *piece of text that can be inserted on the page. The reason for having to add 
 *this is that it makes it possible to have as many parts on a Page as needed.
 *
 */

package com.asap.catalog.dao;

import javax.persistence.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.annotations.Type;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 *
 * @author mortenandersen
 */
@Entity
@Table(name = "part")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Part implements java.io.Serializable {
    
    
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    
    @ManyToOne
    Page page;

    @Type(type = "text")        
    String content;
    String name;
    private String linkTo;
    
    /** Creates a new instance of Part */
    public Part() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }  

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String toString(){
        return ""+id;
    }
    
    public String getViewContent(){
        Log log = LogFactory.getLog(Part.class);
        log.warn("getViewContent called");
        if ( content == null || content.equals("") || content.equals("<p></p>")){
            if (getPage().getParent()==null){
                log.warn("getViewContent returns null");        
                return null;
            }
            else{
                log.warn("getViewContent calls parent getViewPart");        
                return getPage().getParent().getViewPart(name);
            }
        }
        else{
            log.warn("getViewContent returns content - "+content);        
            return content;
        }
    }    

    public String getLinkTo() {
        return linkTo;
    }

    public void setLinkTo(String linkTo) {
        this.linkTo = linkTo;
    }
}
