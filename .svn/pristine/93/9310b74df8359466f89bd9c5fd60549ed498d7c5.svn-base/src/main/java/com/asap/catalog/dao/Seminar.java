package com.asap.catalog.dao;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import com.asap.catalog.enums.CourseComplexity;
import com.asap.catalog.enums.EntranceLevel;
import javax.persistence.OneToOne;

@Entity
@DiscriminatorValue("SEMINAR")
public class Seminar extends Product {

    @OneToOne
    private Event event;

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
    
    public String getType(){
        return "Seminar";
    }
}  
