/*
 * Component.java
 *
 * Created on 14. maj 2007, 21:34
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao;

/**
 *
 * @author mortenandersen
 */
public abstract class Component implements java.io.Serializable{
    
    public abstract Long getId();
    
    public String getTitle(){
        return this.getClass().getName();
    }
     
    public String toString(){
        if (getId() == null){
            return "";
        }
        else{
            return ""+getId();
        }
    }
}
