/*
 * PageManager.java
 *
 * Created on March 28, 2007, 10:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web;

import com.asap.catalog.dao.Page;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;

/**
 *
 * @author asapunov
 */
public class PageManager {
    
    /** Creates a new instance of PageManager */
    public PageManager() {
    }
   
    
    public static Page getPage(String URL) {
        if (URL != null) {
            Page page = (Page) HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Page.class).add(Expression.eq("urlMap", URL)).uniqueResult();
            if (page == null) {
                int index = URL.lastIndexOf("/");
                if (index != -1) {
                    
                    String lastPart = URL.substring(index + 1, URL.length());
                    if (lastPart.equals("*")){
                        if (URL.split("/").length > 2) {
                            int index2 = URL.substring(0, index).lastIndexOf("/");
                            String result = URL.substring(0, index2 + 1) + "*";
                            return getPage(result);
                        } else {
                            return null;
                        }
                    } else {
                        String result = URL.substring(0, index + 1) + "*";
                        return getPage(result);
                    }
                }
                return null;
            } else {
                return page;
            }
        }
        return null;
    }
}
