package com.asap.catalog.dao;

import java.awt.ItemSelectable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn; 
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.IndexColumn;
import org.hibernate.criterion.Restrictions;

import util.HibernateUtil;

import com.asap.core.number.MutableInteger;

@Entity 
@Table(name = "shopcart")
public class ShopCart implements java.io.Serializable {

        @Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String toString() {
		return id + "";
	}

	/*public void addItem(ShopCartItem item, int count) {
		MutableInteger integer = items.get(item);
		if (integer == null) {
			integer = new MutableInteger();
			items.put(item, integer);
		}
		integer.add(count);
	}
         public void removeItem(ShopCartItem item, int count) {
		MutableInteger integer = items.get(item);
		if (integer == null) {
			return;
		}
		integer.subtract(count);
	}

         */

	/**
	 * returns the sum of the products in the shopping cart.
	 */
	public double getSum() {
            try{
                double i = 0;
                for (ShopCartItem item : getItems()) {
                    i += item.getPrice() * item.getOccurences();
                }
                return i;
            } catch(Exception e){
                e.printStackTrace();
                return 0;
            }
	}

	public List<ShopCartItem> getItems() {
            if(getId() == null){
                return null;
            }
            return HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(ShopCartItem.class).add(Restrictions.eq("shopCart",this)).list();
	}

	public void invalidate() {
		// TODO Auto-generated method stub
	}
        
        private double freight = 68;

    public double getFreight() {
        return freight;
    }

    public void setFreight(double freight) {
        this.freight = freight;
    }
}
