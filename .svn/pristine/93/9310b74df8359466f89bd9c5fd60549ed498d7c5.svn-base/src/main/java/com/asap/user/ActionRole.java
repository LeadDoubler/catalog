/*
 * ActionRole.java
 *
 * Created on 20 ���� 2007 �., 21:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.user;

/**
 *
 * @author asapunov
 */
public enum ActionRole {
    ROLE0(0, "Role0"), ROLE1(1, "Role1"), ROLE2(2, "Role2"), ROLE3(
			3, "Role3"), ROLE4(4, "Role4"), ROLE5(5,
			"Role5");

	ActionRole(int value, String name) {
		this.value = value;
		this.name = name;
	}

	private final int value;

	private final String name;

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}
}
