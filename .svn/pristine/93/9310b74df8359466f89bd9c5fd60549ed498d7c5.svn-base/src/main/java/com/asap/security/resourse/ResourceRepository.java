package com.asap.security.resourse;

import java.util.Map;

public interface ResourceRepository {
	public void saveResources(Map<String, SecurityResource> resources);

	public Map<String, SecurityResource> getResources();

}
