package com.asap.catalog.dao;

import com.asap.catalog.enums.BannerType;
import com.asap.catalog.enums.Language;
import com.asap.catalog.explorer.Child;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import javax.persistence.*;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.IndexColumn;

import org.hibernate.annotations.Type;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator; 
import org.hibernate.classic.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.lucene.Indexed;
import org.hibernate.proxy.HibernateProxyHelper;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;
import org.mortena.util.InheritedContentMap;
import util.HibernateUtil;

@Entity
@Table(name = "page")
@DiscriminatorColumn(name = "page_type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("PAGE")
@Indexed
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Page implements Child, java.io.Serializable{
    
    @ManyToOne //(fetch=FetchType.EAGER)
    private Page parent;
    
    @OneToOne
    private Page leftPage;
    
    @OneToOne
    private Page rightPage;
    
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    @DocumentId
    protected Long id;
    
    //@Column(name = "lang")
    private Language language;
    
    @Column (unique = true)
    private String url;
    
    private String urlMap;
    
    private String contentFrom;
    
    private String forward;
    private String contentforward;
    private String keywords;
    
    private String pageType;
    
    
    @Lob
    @Column (name = "picture_binary", length=2097152)
    private byte[] picture_binary;
    private BannerType banner_type = BannerType.NONE;
    
    
    
    
    /**
     * @hibernate.property column="picture_binary"
     **/
    
    public Page getParent () {
        return parent;
    }
    
    public void setParent (Page parent) {
        //TODO: Add to sorted child list...
        //if (parent !=null)
        //    parent.addPage (this);
        this.parent = parent;
    }
        
    transient InheritedContentMap viewParts = new InheritedContentMap (this);
    
    public Map getViewParts (){
        return new InheritedContentMap (this);
    }
    
    @OneToMany (mappedBy="page", fetch=FetchType.EAGER)
    @MapKey (name="name")
    Map<String,Part> parts;
    
    public Map<String, Part> getParts () {
        return parts;
    }
    
    private long pagePosition;
    
    @OneToMany (mappedBy = "parent" ) //, fetch=FetchType.EAGER
    @IndexColumn(name = "pagePosition")
    List<Page> children;
    
    public Collection<Page> getMyChildren(){
        List<Page> children =  HibernateUtil.getSessionFactory().getCurrentSession().createCriteria(Page.class).add(Expression.eq("parent",this)).addOrder(Order.asc("pagePosition")).list();
        LinkedHashSet<Page> v = new LinkedHashSet();
        //List<Page> children = getChildren();
        for (Page p: children){
            if (p!=null){
               v.add(p); 
            }
        }
        return v;
        //return //new LinkedHashSet(getChildren());
    }
    
    public List<Page> getChildren () {
        return children;
    }
    
    public boolean getChildless () {
        if(getChildren () != null)
            if(getChildren().size() > 0)
                return false;
        
        return true;
    }
    
    public void setChildren (List<Page> children) {
        this.children = children;
    }
    
    @Field(index=Index.TOKENIZED, store=Store.YES)
    private String title;
    private String heading;
    
    @Type (type = "text")
    private String description;
    
    @Type (type = "text")
    private String content;
    
    public String getTitle (){
        return title;
    }
    
    public String getTreeTitle (){
        String title=" ";
        Page tmp = this;
        while(tmp.getParent () != null){
            title += "- ";
            tmp = tmp.getParent ();
        }
        return title+getTitle ();
    }
    
    public Long getId () {
        return id;
    }
    
    public String getDescription (){
        return description;
    }
    
    public String getContent (){
        return content;
    }
    
    
    public void setId (Long id) {
        this.id = id;
    }
    
    public void setTitle (String title){
        this.title = title;
    }
    
    public void setDescription (String desciption){
        this.description = desciption;
    }
    
    public void setContent (String content){
        this.content = content;
    }
    
    public String toString (){
        if (id == null){
            return null;
        }
        return ""+id; //turns the Long value into a String
    }
    
   /* public String getOLDXML() {
        XStream xstream = new XStream(new DomDriver());
        xstream.alias("page", Page.class);
        String xml = xstream.toXML(this);
        return xml;
    }*/
    
    class IDComparator implements Comparator<Page> {
        public  int compare (Page p1, Page p2){
            if (p1 == null){
                return 1;
            }
            if (p2 == null){
                return -1;
            }
            return (p1.getId ().compareTo (p2.getId ()));
        }
    }
    
    public List<Page> getSortedChildList () {
        //TODO : implement getting sorted list
        List<Page> result = new ArrayList <Page>();
        List<Page> startList = new ArrayList <Page>();
        for(Page child : children) {
            //System.out.println("PAGE = "+child);
            if (child != null && child.getLeftPage () == null && child.getRightPage () != null) {
                startList.add (child);
            }
        }
        if (startList.size () == 0) {
            // No start - use IDComparator
            TreeSet set = new TreeSet (new IDComparator ());
            set.addAll (children);
            result.addAll (set);
        } else if (startList.size () == 1) {
            // Start found ... use it for iterating
            Page page = startList.get (0);
            List<Page> list = new ArrayList (children);
            list.remove (page);
            Page nextPage = page;
            while (nextPage != null) {
                result.add (nextPage);
                list.remove (nextPage);
                nextPage = nextPage.getRightPage ();
            }
            if (list.size () != 0) {
                TreeSet set = new TreeSet (new IDComparator ());
                set.addAll (list);
                result.addAll (set);
            } else {
                return result;
            }
        } else {
            // Two or more starts - use ID Comparator
            TreeSet set = new TreeSet (new IDComparator ());
            set.addAll (children);
            result.addAll (set);
        }
        Page pp = null;
        Page cp = null;
        for (Page page : result) {
            page.setLeftPage (pp);
            if (pp!=null){
                pp.setRightPage (page);
            }
            pp = page;
        }
        if (pp != null){
            pp.setRightPage (null);
        }
        for (Page page : result) {
            if ( HibernateUtil.getSessionFactory ().getCurrentSession ().contains( page ) ){
                HibernateUtil.getSessionFactory ().getCurrentSession ().update (page);
            }
            
        }
        return result;
    }
    
    
    
    public String getXml (){
        /*if (deactivated != null && deactivated.equals("yes")){
            return null;
        }*/
        String s = "<page><id>"+id+"</id><title>"+title+"</title>";
        s+="<children>";
        if (getMyChildren() != null){
            for (Iterator<Page> iterator = getMyChildren().iterator (); iterator.hasNext ();) {
                Page page = iterator.next ();
                if (page !=null && ! ( "yes".equals(page.getDeactivated() ) ) && ! "yes".equals(page.getHide()) )
                    s+=page.getXml ();
            }
        }
            /*
        for ( Iterator<Product> iterator = products.iterator(); iterator.hasNext();) {
            Product product = iterator.next();
            s+=product.getXml();
        }*/
        s+="</children>";
        s+="</page>";
        return s;
    }
    
   /*  public String getMenuXml() {
        XStream xstream = new XStream(new DomDriver());
        xstream.alias("page", Page.class);
        String xml = xstream.toXML(this);
        return xml;
    }*/
    
    public void addPage (Page child) {
        if (this.getChildren ()==null){
            children = new ArrayList ();
        }
        children.add (child);
        //child.setParent(this);
    }
    
    public List<Page> addAllChildren (List<Page> children) {
        children.add (this);
        List<Page> childs = getChildren ();
        if (childs != null){
            for (Iterator<Page> iterator = childs.iterator (); iterator.hasNext ();) {
                Page page = iterator.next ();
                page.addAllChildren (children);
            }
        }
        return children;
    }
    
    public void initializeChildren () {
        if (getChildren ()!=null){
            for (Iterator<Page> iterator = children.iterator (); iterator.hasNext ();) {
                Page page = iterator.next ();
                if (page!=null)
                    page.initializeChildren ();
            }
        } else{
            getId ();
        }
    }
    
    public String getUrl () {
        return url;
    }
    
    public void setUrl (String url) {
        this.url = url;
    }
    
    public String getMenu (){
        if (getParent () == null){
            if(getChildren () != null && !getChildren ().isEmpty ()){
                Page firstPage = getChildren ().get (0);
                if (firstPage !=null){
                    return firstPage.getXml ();
                }
            }
        }
        if (getParent () == null || getParent ().getParent () == null ){
            //initializeChildren();
            return getXml ();
        } else{
            return getParent ().getMenu ();
        }
    }
    
    // Wrapper method for finding language root node
    public Page getRoot () {
        if (language == null){
            language = Language.DANISH;
        }
        Session session = HibernateUtil.getSessionFactory ().getCurrentSession ();
        List<Page> pages = session.createCriteria (Page.class)
        .add (Expression.isNull ("parent"))
        .add (Expression.eq ("language",language)).list ();
        
        StringBuffer sb = new StringBuffer ();
        if (pages!=null && pages.size ()>0){
            Page front = pages.get (0);
            front.initializeChildren ();
            return pages.get (0);
        } else{
            Page page = new Page ();
            page.setTitle ("Root");
            session.save (page);
            return page;
        }
    }
    
    public String getTabs (){
        if (getParent () == null ){
            //initializeChildren();
            return getXml ();
        } else{
            return getParent ().getMenu ();
        }
    }
    
    public List getAncestors (){
        List list;
        if (getParent () == null){
            list = new ArrayList ();
        } else{
            list = getParent ().getAncestors ();
        }
        list.add (this);
        return list;
    }
    
    /*public String getContentPart1 (){
        return getViewPart ("cp1");
    }
    
    public String getContentPart2 (){
        return getViewPart ("cp2");
    }
    
    public String getContentPart3 (){
        return getViewPart ("cp3");
    }
    
    public String getContentPart4 (){
        return getViewPart ("cp4");
    }
    
    public String getContentPart5 (){
        return getViewPart ("cp5");
    }
    
    public String getContentPart6 (){
        return getViewPart ("cp6");
    }
    
    public String getContentPart7 (){
        return getViewPart ("cp7");
    }
    
    public String getContentPart8 (){
        return getViewPart ("cp8");
    }
    
    public String getContentPart9 (){
        return getViewPart ("cp9");
    }
    
    public String getContentPart10 (){
        return getViewPart ("cp10");
    }*/
    
    public String getViewPart (String name) {
        if(getParts ()!=null && getParts ().get (name)!=null){
            return getParts ().get (name).getViewContent ();
        } else if (getParent ()!=null){
            return getParent ().getViewPart (name);
        } else{
            return null;
        }
    }
    
    public String getForward () {
        return forward;
    }
    
    public void setForward (String forward) {
        this.forward = forward;
    }
    
    public String getKeyword () {
        return getKeywords ();
    }
    
    public void setKeyword (String keyword) {
        this.setKeywords (keyword);
    }
    
    public String getKeywords () {
        return keywords;
    }
    
    public void setKeywords (String keywords) {
        this.keywords = keywords;
    }
    
    public byte[] getPicture_binary () {
        if(picture_binary == null && getParent () != null)
            return getParent ().getPicture_binary ();
        else
            return picture_binary;
    }
    
    public void setPicture_binary (byte[] picture_binary) {
        this.picture_binary = picture_binary;
    }
    
    public BannerType getBanner_type () {
        return banner_type;
    }
    
    public void setBanner_type (BannerType banner_type) {
        this.banner_type = banner_type;
    }
    
    public String getUrlMap () {
        return urlMap;
    }
    
    public void setUrlMap (String urlMap) {
        this.urlMap = urlMap;
    }
    
    public BannerType getEnheritedBannerType () {
        // Finding first page object in hirachi with BannerType != NONE
        Page image_page = this;
        
        while((image_page.getBanner_type () == BannerType.NONE) && (image_page.getParent () != null)){
            image_page = image_page.getParent ();
        }
        return image_page.getBanner_type ();
    }
    
    public Language getLanguage () {
        return language;
    }
    
    public void setLanguage (Language language) {
        this.language = language;
    }
    
    /*public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(HibernateProxyHelper.getClassWithoutInitializingProxy(o) instanceof Page.class ) ){
            return false;
        }
        final Page page = (Page) o;
        if (null != id ?
            !id.equals(page.getId()) :
            null != page.getId())
               return false;
        return true;
    }
    public int hashCode() {
        return null != id ? id.hashCode() : super.hashCode();
    }*/
    
    private List<Page> getTreeExcluded (Page root,Long this_id,List<Page> pages){
        if(root !=null && root.getId ()!=null && this_id != null && ! root.getId ().equals (this_id)){
            pages.add (root);
            if (root !=null && root.getChildren ()!=null){
                Iterator it = root.getChildren ().iterator ();
                while(it.hasNext ()){
                    getTreeExcluded ((Page)it.next (),this_id,pages);
                }
            }
        }
        return pages;
    }
    
    private List<Page> getTree (Page root,List<Page> pages){
        if(root != null){
            if(root.getId() != null){
                pages.add (root);
            
                if (root.getChildren ()!=null){
                    Iterator it = root.getChildren ().iterator ();
                    while(it.hasNext ()){
                        getTree ((Page)it.next (),pages);
                    }
                }
            }
        }
        return pages;
    }
    
    public List<Page> getTree () {
        List<Page> pages = (List<Page>)new LinkedList ();
        return getTree (getRoot () , pages);
    }
    
    public List<Page> getTreeExcluded () {
        List<Page> pages = (List<Page>)new LinkedList ();
        return getTreeExcluded ( getRoot () , this.getId () , pages);
    }
    
    public Page getLeftPage () {
        return leftPage; 
    }
    
    public void setLeftPage (Page leftPage) {
        this.leftPage = leftPage;
    }
    
    public Page getRightPage () {
        return rightPage;
    }
    
    public void setRightPage (Page rightPage) {
        this.rightPage = rightPage;
    }
    
    
    public void setTheLeft(Page leftPage){
        //Removing from current spot
        Page pLeft = getLeftPage();
        Page pRight = getRightPage();        
        if (pLeft != null){
            pLeft.setRightPage(pRight);
            if ( HibernateUtil.getSessionFactory ().getCurrentSession ().contains( pLeft ) ){               
                HibernateUtil.getSessionFactory ().getCurrentSession ().update (pLeft);
            }
        }
        if (pRight != null){
            pRight.setLeftPage(pLeft);        
            if ( HibernateUtil.getSessionFactory ().getCurrentSession ().contains( pRight) ){               
                HibernateUtil.getSessionFactory ().getCurrentSession ().update (pRight);
            }            
        }
        //Inserting it on new pos:
        if (leftPage != null && leftPage.getAncestors () != null){
            setLeftPage(leftPage);
            setRightPage(leftPage.getRightPage());
            leftPage.setRightPage( this );            
            HibernateUtil.getSessionFactory ().getCurrentSession ().update (leftPage);
        }
        else{
            setLeftPage(null);
            Page firstPage = getParent().getSortedChildList().get(0);
            firstPage.setLeftPage(this);
            setRightPage(firstPage);
            HibernateUtil.getSessionFactory ().getCurrentSession ().update (firstPage);
        }        
        HibernateUtil.getSessionFactory ().getCurrentSession ().update (this);        
    }
    
    public Locale getLocale(){
        if ( language.DANISH.equals( this.getLanguage() ) ) {
            return new Locale("da","DK");
        }             
        else{
            return new Locale("en","US");
        }
    }
    
    public String getType(){
        return "Page";
    }

    public String getContentforward() {
        return contentforward;
    }

    public void setContentforward(String contentforward) {
        this.contentforward = contentforward;
    }

    public void setPageType(String type) {
        this.pageType = type;
    }
    
    public String getPageType(){
        return this.pageType;
    }

    public long getPagePosition() {
       
        return pagePosition;
    }

    public void setPagePosition(long pagePosition) {
        
        this.pagePosition = pagePosition;
    }

    public String getHeading() {
        if(heading == null || heading == ""){
            return title;
        }
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }
    
    private String deactivated;

    public String getDeactivated() {
        return deactivated;
    }

    public void setDeactivated(String deactivated) {
        this.deactivated = deactivated;
    }
    
    private String hide;
    
    
    
    public void changeDeactivateionChildrenTo(String newValue){
        setDeactivated(newValue);
        HibernateUtil.getSessionFactory().getCurrentSession().saveOrUpdate(this);
        for (Page child : getChildren()){
            child.changeDeactivateionChildrenTo(newValue);
        }
    }

    public String getHide() {
        return hide;
    }

    public void setHide(String hide) {
        this.hide = hide;
    }

    
    
    
}

