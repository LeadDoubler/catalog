package com.asap.catalog.enums;

public enum Language {NONE(0,"NONE","nan"),DANISH(1,"Dansk","da"),ENGLISH(2,"English","en");

Language(int value, String name, String code) {
		this.value = value;
		this.name = name;
                this.code = code;
	}

	private final int value;

	private final String name;
        
        private final String code;

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}
        
        public String getCode() {
            return code;
        }
}