/*
 * AgentController.java
 *
 * Created on 13. maj 2007, 15:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.blob.pas.agent;

import java.util.Date;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;

/** 
 *
 * @author mortenandersen
 */
public class AgentController {
    
    /** Creates a new instance of AgentController */
    public AgentController() {
    }

    public void execute(){
      /*  System.out.println("Executing AgentController"+new Date().getSeconds());
        Session session = HibernateUtil.getSessionFactory().openSession();
        Criteria crit = session.createCriteria(Todo.class);
        crit.add(Expression.eq( "status", Status.SUBMITTED ));
        crit.add( Expression.gt ( "numbersOfMailsLeft" , 0 ) );
        crit.add( Expression.le ( "mailDate", new Date() ) );
        List<Todo> list = crit.list();
        SessionFactory sf = HibernateUtil.getSessionFactory();
        sf.getCurrentSession().beginTransaction();
        for( Todo todo : list){
            todo.act();
            sf.getCurrentSession().saveOrUpdate( this );
        }
        sf.getCurrentSession().getTransaction().commit();
        sf.close();*/
    }
    
    /*private void act(Todo todo){
        
    }*/
     
}
