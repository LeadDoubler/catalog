/*
 * Sitemap.java
 *
 * Created on 2. april 2007, 12:16
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.page;

import com.asap.web.CatalogActionBean;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;

/**
 *
 * @author Jens Rosenberg
 */
public class Sitemap extends CatalogActionBean{
    
    /** Creates a new instance of Sitemap */
   @DefaultHandler
   public Resolution init() {
       return new ForwardResolution("/page/sitemap.jsp");
   }
    
}
