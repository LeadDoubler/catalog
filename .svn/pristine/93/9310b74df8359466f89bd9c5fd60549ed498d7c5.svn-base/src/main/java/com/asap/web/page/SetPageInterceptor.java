/*
 * SetPageInterceptor.java
 *
 * Created on 29. marts 2007, 09:24
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.page;

import com.asap.catalog.dao.Page;
import com.asap.web.PageManager;
import javax.servlet.http.HttpServletRequest;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.controller.ExecutionContext;
import net.sourceforge.stripes.controller.Interceptor;

/**
 *
 * @author mortenandersen
 */
public class SetPageInterceptor implements Interceptor{
    
    public SetPageInterceptor(){}
        
    public Resolution intercept(ExecutionContext ctx) throws Exception {
        Resolution res = ctx.proceed();
        HttpServletRequest request = ctx.getActionBeanContext().getRequest();
        Page page = (Page) request.getAttribute("page");
        if ( page == null ) {
            String uri = request.getRequestURI();
            page = PageManager.getPage(uri);
            request.setAttribute("page",page);            
        }
        return res;
    }
    
}
