/*
 * ShopcartManager.java
 *
 * Created on 22. maj 2007, 13:23
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.catalog.dao.manager;

import com.asap.catalog.dao.ShopCartOrder;
import java.util.List;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import util.HibernateUtil;

/**
 *
 * @author Jens Rosenberg
 */
public class ShopcartManager {
    
    public List<ShopCartOrder> getOrders(){
        return HibernateUtil.getSessionFactory().getCurrentSession()
            .createCriteria(ShopCartOrder.class)
            .addOrder(Order.desc("date")).list();
    }
}
