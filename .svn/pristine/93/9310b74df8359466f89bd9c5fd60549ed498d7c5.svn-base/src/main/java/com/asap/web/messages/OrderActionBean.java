/*
 * OrderActionBean.java
 *
 * Created on 25. maj 2007, 21:40
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.messages;

import com.asap.catalog.dao.ShopCartOrder;
import com.asap.web.CatalogActionBean;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;

/**
 *
 * @author mortenandersen
 */
public class OrderActionBean extends CatalogActionBean {
    
    private ShopCartOrder order;
   
    @DefaultHandler
    public Resolution viewOrder(){
        return new ForwardResolution("/shopcart/mailOrder.jsp");
    }
    
    /** Creates a new instance of OrderActionBean */
    public OrderActionBean() {
    }

    public ShopCartOrder getOrder() {
        return order;
    }

    public void setOrder(ShopCartOrder order) {
        this.order = order;
    }

  
}
