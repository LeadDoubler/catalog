package com.asap.web;

import com.asap.catalog.dao.Page;
import javax.servlet.http.HttpServletRequest;
import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.action.After;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.controller.StripesRequestWrapper;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import util.HibernateUtil;
import net.sourceforge.stripes.controller.StripesFilter;
import net.sourceforge.stripes.controller.FlashScope;


/**
 * Simple ActionBean implementation that all ActionBeans will extend.
 *
 * @author Tim Fennell
 */
public abstract class CatalogActionBean implements ActionBean {
    private CatalogActionBeanContext context;
    Session session;
    protected String PREPATH = "/WEB-INF/view";
    private String FOLDER = "default";
    
    
    protected Resolution forward(){
        return new ForwardResolution(PREPATH+"/"+getFOLDER()+"/"+this.getContext().getEventName()+".jsp");
    }
    
    public Session getSession(){
        if (session == null){
            session = HibernateUtil.getSessionFactory().getCurrentSession();
        }
        return session;
    }

    public void setContext(ActionBeanContext context) {
        this.context = (CatalogActionBeanContext) context;
        session = HibernateUtil.getSessionFactory().getCurrentSession();
    }

    /** Gets the ActionBeanContext set by Stripes during initialization. */
    public CatalogActionBeanContext getContext() {
        return this.context;
    }
    
    @After
    public void setPageOnRequest(){
        long curtime = System.currentTimeMillis();
        HttpServletRequest request = context.getRequest();
        Page page = (Page) request.getAttribute("page");
        ////System.out.println("setPageOnRequest");
        if ( page == null ) {
            String URI = request.getRequestURI ();
            String contextPath =  request.getContextPath ();
            boolean startWith = URI.startsWith (contextPath);
            if  (startWith) {
                //Remove contextpath
                URI = URI.substring (contextPath.length ());
            }
            //System.out.println("URI = "+URI);
            page = (Page) getSession().createCriteria(Page.class).add(Expression.like("urlMap",URI)).uniqueResult();
            if (page == null){
                //String[] urlParts = URI.split("/");
                int lengthOfLast = URI.lastIndexOf("/");//urlParts[urlParts.length-1].length();
                URI = URI.substring(0,lengthOfLast);
                //System.out.println("URI after removal of last part "+URI);
                try{
                    page = (Page) getSession().createCriteria(Page.class).add(Expression.like("urlMap",URI+"/*")).uniqueResult();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }  
            if (page == null){
                page = (Page) this.getContext().getRequest().getSession().getAttribute("page");
            }
            if (page == null){
                com.asap.catalog.dao.manager.PageManager pm = new com.asap.catalog.dao.manager.PageManager();
                if ( "DK".equals( request.getLocale().getCountry() ) ) {
                    page = pm.getDanishLandingPage();//  .getPage(URI);
                }            
                else{
                    page = pm.getEnglishLandingPage();
                }
            }
            else{
                 //System.out.println("Found page for "+URI+" using urlMap "+page.getTitle());           
            }
            request.getSession().setAttribute("page",page); 
            long curtime2 = System.currentTimeMillis();
           // System.out.println("Time to run After in CatalogActionBean"+(curtime2-curtime) );
            request.setAttribute("curtime",curtime);
        }
    }

    public String getFOLDER() {
        return FOLDER;
    }

    public void setFOLDER(String FOLDER) {
        this.FOLDER = FOLDER;
    }
}