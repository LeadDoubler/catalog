package com.asap.catalog.dao;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "product_type", discriminatorType = DiscriminatorType.STRING)
@DiscriminatorValue("PRODUCT")
public class Product extends Component{

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected Long id;
 
	private Double price;
        
        @Lob
        @Column (name = "picture", length=2097152)
        private  byte[] picture;
        
        @ManyToOne
	@JoinColumn(name = "category")
	private Category category;

        @Type(type = "text")
        protected String description;
        @Type(type = "text")
    private String intro;

        protected boolean deleted;

	protected String title;
        
	//@Type(type = "com.asap.core.number.MutableIntegerType")
	//private MutableInteger count;
        
        public Product(){
            deleted = false;
        }
        
	public boolean equals(Object object) {
		if (object instanceof Product) {
			return (((Product) object).getId().equals(getId()) ? true : false);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return getId().intValue();
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Double getPrice() {
            if(price == null) {
                return new Double(0);
            }
            else return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getXml() {
		return "<product><title>" + title + "</title><id>" + id
				+ "</id><class>" + this.getClass().getName()
				+ "</class></product>";
	}

        public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String toString() {
            if(getId() != null){
                return getId() +"";
            }
            else{
                return null;
            }
	}

	public String getType() {
		return "Product";
	}

	/*public MutableInteger getCount() {
		return count;
	}

	public void setCount(MutableInteger count) {
		this.count = count;
	}

	public void setCount(Long count) {
		this.count = new MutableInteger(count);
	}

	public boolean incrementCount() {
		count.increment();
		return true;
	}

	public boolean decrementCount() {
		if (count.getValue() <= 0)
			return false;
		count.decrement();
		return true;
	}

	public boolean incrementCount(int amount) {
		count.add(amount);
		return true;
	}

	public boolean incrementCount(long amount) {
		count.add(amount);
		return true;
	}

	public boolean decrementCount(int amount) {
		if (count.getValue() < amount)
			return false;
		count.subtract(amount);
		return true;
	}

	public boolean decrementCount(long amount) {
		if (count.getValue() < amount)
			return false;
		count.subtract(amount);
		return true;
	}*/

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }
    
    private Boolean active;

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
