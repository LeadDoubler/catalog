 /*
 * DateTypeConverter.java
 *
 * Created on 15. marts 2007, 09:35
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.stripes.validation;

import java.util.Collection;
import java.util.Locale;
import net.sourceforge.stripes.validation.TypeConverter;
import net.sourceforge.stripes.validation.ValidationError;

/**
 *
 * @author Hanne Matras
 */
public class DateTypeConverter extends  net.sourceforge.stripes.validation.DateTypeConverter{
    
    /** Creates a new instance of DateTypeConverter */
    public DateTypeConverter() {
    }

    public void setLocale(Locale locale) {
    }

}
