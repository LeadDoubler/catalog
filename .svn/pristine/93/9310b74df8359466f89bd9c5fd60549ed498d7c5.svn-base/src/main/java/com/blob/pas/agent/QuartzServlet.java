/*
 * QuartzServlet.java
 *
 * Created on 13. maj 2007, 15:46
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.blob.pas.agent;

import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import net.sourceforge.stripes.util.ResolverUtil;
import org.quartz.JobDetail;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.helpers.TriggerUtils;
import org.quartz.impl.StdSchedulerFactory;

/**  
 *
 * @author mortenandersen
 */
public class QuartzServlet extends HttpServlet{
    //Thread thread = new AgentThread();
    
    private org.quartz.Scheduler scheduler;
    
    /** Creates a new instance of QuartzServlet */
    public QuartzServlet() {
        
        }
    
    public void destroy(){
        try {
            scheduler.shutdown();
        } catch (SchedulerException ex) {
            ex.printStackTrace();
        }
    }
    
    public void start() throws SchedulerException{
        // Use the factory to create a Scheduler instance
        scheduler = StdSchedulerFactory.getDefaultScheduler();
         
        // Other neccessary Job parameters here

        // Create a Trigger that fires every 60 seconds
        
        
        // Start the Scheduler running
        scheduler.start();
        
        // new StreamingResolution("text/html","Scheduler started..."+getContext().getServletContext().getInitParameter("link") ) ;
        
        ResolverUtil<Agent> resolver = new ResolverUtil<Agent>();
        List<String> l = new Vector();
        l.add("WEB-INF/classes");
        resolver.setLocationFilters(l);
        resolver.loadImplementationsFromContextClassloader(Agent.class);
        Set<Class<? extends Agent>> agents = resolver.getClasses();
        for (Class agentClass : agents) {
			// aConf.addAnnotatedClass(component);
			if (!agentClass.isInterface() && !Modifier.isAbstract(agentClass.getModifiers())) {
				System.out.println("Adding agent = " + agentClass.getName());
				try {
					Agent agent = (Agent) agentClass.newInstance();
					scheduleAgentJob(agent);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
        
    }

    private void scheduleAgentJob(final Agent agent) throws SchedulerException {
        Trigger trigger = TriggerUtils.makeSecondlyTrigger(agent.getSecondsBetweenRun());
        trigger.setStartTime(agent.getStartDate());
        trigger.setName(agent.getName());
        trigger.setGroup(agent.getGroup());
        
         
        // JobDetail holds the definition for Jobs
        JobDetail jobDetail =  new JobDetail();
        jobDetail.setJobClass(agent.getJob().getClass());
        jobDetail.setName(agent.getName());
        jobDetail.setGroup(agent.getGroup());
       
        // Setup the Job and Trigger with the Scheduler
        scheduler.scheduleJob(jobDetail, trigger );
        System.out.println("Scheduled - "+agent.getName());
    }
    
    public void init() throws ServletException{        
        try {
            start();    
        } catch (SchedulerException ex) {
            //ex.printStackTrace();
        }    
        
        /*super.init();
        System.out.println("Starting Quartz");
        JobDetail jd = new JobDetail("TestJOB",null, AgentController.class);
        SimpleTrigger trigger = new SimpleTrigger("trigger1", "group1");
        trigger.setRepeatCount(10);
        trigger.setRepeatInterval(1000); // milliseconds
        trigger.setStartTime(new Date()); //Start now
        try {
           SchedulerFactory schedFact = new StdSchedulerFactory();         
           org.quartz.Scheduler scheduler = schedFact.getScheduler();
           scheduler.scheduleJob(jd,trigger);
        } catch (SchedulerException e) {
            //log.warn("An error occurred - "+e.getMessage());
            e.printStackTrace(); 
        }     
*/
            
         /*   
            SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();
            Scheduler sched = schedFact.getScheduler();        
            sched.start();
            JobDetail jobDetail = new JobDetail("todoAgent",null,AgentController.class);
            Trigger trigger = TriggerUtils.makeSecondlyTrigger();//.makeHourlyTrigger(); // fire every hour
            trigger.setStartTime( new Date() );  
            trigger.setName("todoAgent");
            sched.scheduleJob(jobDetail, trigger);*/
        
    }
    
}
