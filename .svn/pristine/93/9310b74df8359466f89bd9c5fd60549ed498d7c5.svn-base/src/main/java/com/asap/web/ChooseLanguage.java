/*
 * ChooseLanguage.java
 *
 * Created on 23. april 2007, 18:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web;

import com.asap.catalog.dao.Page;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import org.mortena.stripes.conf.StripesLocalePicker;
import org.omg.PortableServer.REQUEST_PROCESSING_POLICY_ID;

/**
 *
 * @author mortenandersen
 */
public class ChooseLanguage extends CatalogActionBean{
    
    /** Creates a new instance of ChooseLanguage */
    public ChooseLanguage() {
    }
    
    public Resolution chooseLanguage(){
        this.getContext().getRequest().getSession().setAttribute(StripesLocalePicker.LOCALE,this.getContext().getRequest().getLocale());
        return new RedirectResolution("/startup/Startup.action");
    }
    
    public Resolution changeLanguage(){
        changeLanguage(language,country,this.getContext().getRequest());
        return new RedirectResolution("/startup/Startup.action");
    }
    
    public void changeLanguage(String country,String language, HttpServletRequest request){
        Locale locale = new Locale(language,country);
        HttpSession session = request.getSession(true);
        session.setAttribute(StripesLocalePicker.LOCALE,locale);
        com.asap.catalog.dao.manager.PageManager pm = new com.asap.catalog.dao.manager.PageManager();
            
        Page page = null;
        if ( "DK".equals( locale.getCountry() ) ) {
            page = pm.getDanishLandingPage();//  .getPage(URI);
        }            
        else{
            page = pm.getEnglishLandingPage();
        }
        request.setAttribute("page",page);    
        
    }
    
    private String country;
    
    private String language;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    
    
}
