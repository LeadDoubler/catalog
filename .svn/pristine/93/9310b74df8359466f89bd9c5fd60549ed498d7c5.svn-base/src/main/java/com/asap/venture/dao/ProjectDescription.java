/*
 * ProjectDescription.java
 *
 * Created on 27. marts 2007, 10:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.venture.dao;

import com.asap.catalog.dao.Category;
import com.asap.catalog.enums.Language;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

/**
 *
 * @author mortenandersen
 */
@Entity
@Table(name = "projectdescription")
public class ProjectDescription {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private Language language;
    
    
    
    public String toString(){
        return ""+getId();
    }
    
    public boolean equals(Object obj){
        if (obj instanceof ProjectDescription){
            ProjectDescription pr2 = (ProjectDescription) obj;
            return getId() == pr2.getId();            
        }
        return false;
    }
    
    private String title;
    
    private Date startdate;
    
    @Type(type="text")
    private
    String business;
    
    @Type(type="text")
    private
    String ipr;
    
    @Type(type="text")
    private
    String management;
    
    
    
    @ManyToOne
    private Category category;
   
    
    /** Creates a new instance of ProjectDescription */
    public ProjectDescription() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }


    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getIpr() {
        return ipr;
    }

    public void setIpr(String ipr) {
        this.ipr = ipr;
    }

    public String getManagement() {
        return management;
    }

    public void setManagement(String management) {
        this.management = management;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    
    
    
}
