package com.asap.web.product;

import com.asap.catalog.dao.ProductShopCartItem;
import com.asap.catalog.dao.ShopCart;
import com.asap.security.Role;
import com.asap.security.Secure;
import java.util.List;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import org.hibernate.criterion.Restrictions;

import com.asap.catalog.dao.Product;
import com.asap.web.CatalogActionBean;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import net.sourceforge.stripes.action.FileBean;
import net.sourceforge.stripes.action.StreamingResolution;
import pictures.PictureUtil;

public class ProductActionBean extends CatalogActionBean {
    private Product product;
    private int amount;
    
    String viewFolder = "product";
    
    String PREPATH = "/WEB-INF/view/"+viewFolder+"/";
    
    public String getPREPATH(){
        return PREPATH;
    }
    
    private FileBean photo;
    
    
    public FileBean getPhoto() {
        return photo;
    }

    public void setPhoto(FileBean photo) {
        this.photo = photo;
    }
    
    public Resolution image () {
        InputStream reader = new ByteArrayInputStream (getProduct().getPicture());
        return new StreamingResolution ( "image/jpg", reader);
    }
    
    @Secure(role=Role.MODERATOR, currentUser=true)
    public Resolution save () {
        savePhoto();
        getSession().saveOrUpdate(product);
        return new ForwardResolution(PREPATH+"saved.jsp");
    }
    
    public void savePhoto(){
        Product prod = getProduct();
        FileBean photo = this.photo;
        savePhoto(photo, prod);
    }

    public void savePhoto( final FileBean photo, final Product prod ) {
        if (photo!=null && prod != null) {
            if (photo.getContentType ().startsWith ("image")) {
                byte[] bytes = new byte[(int)photo.getSize ()];
                try {
                    InputStream istream = photo.getInputStream ();
                    //istream.read (bytes);
                    BufferedImage bi = ImageIO.read(istream); 
                    BufferedImage scaled = PictureUtil.scaleImage(bi, 150); //-1,75
                    //BufferedImage scaled = PictureUtil.scaleImage(bi);
                    // O P E N
                    ByteArrayOutputStream baos = new ByteArrayOutputStream( 1000 );
                    // W R I T E
                    ImageIO.write( scaled, "jpeg" , baos );
                    // C L O S E
                    baos.flush();
                    byte[] resultImageAsRawBytes = baos.toByteArray();

                    baos.close();
                    prod.setPicture (resultImageAsRawBytes);
                    System.out.println("Photo saved in product.");
                } catch (IOException ex) {
                    ex.printStackTrace ();
                }
            }
        }
    }
    
    @DefaultHandler
    public Resolution list() {
        return new ForwardResolution("/product/list.jsp");
    }
    
    public Resolution view(){
        return getForward();
    }
    
    public Resolution inlineView(){
        return getForward();
    }
    
    public Resolution listProducts(){
        return getForward();
    }
    
    public Resolution listDeleted() {
        return new ForwardResolution("/product/listDeleted.jsp");
    }
    
    private String frw;
    
    public Resolution addToShopCart () {
        getSession ().getSessionFactory ().getCurrentSession ().saveOrUpdate (product);
        ShopCart shopCart = getContext ().getShopCart ();
        if(shopCart.getId() == null) getSession ().getSessionFactory ().getCurrentSession ().saveOrUpdate (shopCart);
        List<ProductShopCartItem> list = getSession().createCriteria(ProductShopCartItem.class).add(Restrictions.eq("shopCart",shopCart)).add(Restrictions.eq("product",product)).list();
        ProductShopCartItem psci;
        if(!list.isEmpty()){
            psci = list.get(0);
        }else{
            psci = new ProductShopCartItem ();
            psci.setProduct(product);
            psci.setShopCart(shopCart);
        }
        
        if(getAmount() >= 0){
            psci.setOccurences(psci.getOccurences()+amount);
        }else{
            psci.increaseOccurences();
        }
        
        getSession ().getSessionFactory ().getCurrentSession ().saveOrUpdate (psci);
        if (getFrw() !=null && getFrw().length()>0){
            System.out.println("Frw = "+getFrw());
            return new ForwardResolution(getFrw());
        }
        System.out.println("standard-forward");
        return new ForwardResolution ("/shopcart/view.jsp");
    }

    public Product getProduct() {
        System.out.println("getProduct called");
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution delete(){
        product.setDeleted(true);
        getSession ().saveOrUpdate (product);
        return getForward();
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution restore(){
        product.setDeleted(false);
        getSession ().saveOrUpdate (product);
        return getForward();
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    public ForwardResolution getForward(){
        return new ForwardResolution(getPREPATH()+this.getContext().getEventName()+".jsp");
    }
    
    public Resolution edit() {
        return getForward();
    }
    
    public List<Product> getComponents(){
        return getSession().createCriteria(Product.class).list();
    }

    public String getFrw() {
        return frw;
    }

    public void setFrw(String frw) {
        this.frw = frw;
    }
    
}
