package com.asap.catalog.dao;

import java.io.Serializable;
import javax.persistence.Column;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;

@Entity
@Inheritance (strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn (name = "type", discriminatorType = DiscriminatorType.STRING)
public abstract class ShopCartItem implements Serializable {

    @ManyToOne
    private ShopCart shopCart;
    
    @Id
    @Column (name = "id")
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;
    private int occurences = 0;
    
    public abstract boolean equalsItem (Object item);
    public abstract String getName ();
    public abstract String getDescription ();
    
    public Double getPrice (){
        return new Double(0);
    }
    
    public Double getTotalprice(){
        return getPrice() * getOccurences();
    }
    
    public Long getId () {
        return id;
    }
    
    public void setId (Long id) {
        this.id = id;
    }

    public int getOccurences() {
        return occurences;
    }

    public void setOccurences(int occurences) {
        this.occurences = occurences;
    }
    
    public void increaseOccurences(){
        occurences++;
    }
    
    public void decreateOccurences(){
        occurences--;
    }

    public ShopCart getShopCart() {
        return shopCart;
    }

    public void setShopCart(ShopCart shopCart) {
        this.shopCart = shopCart;
    }
}
