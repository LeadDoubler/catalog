/*
 * ProjectDescriptionActionBean.java
 *
 * Created on 13. februar 2007, 13:50
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.asap.web.projectDescription;

import com.asap.catalog.dao.Category;
import com.asap.catalog.enums.Language;
import com.asap.security.Role;
import com.asap.security.Secure;
import com.asap.venture.dao.ProjectDescription;
import com.asap.web.CatalogActionBean;
import java.text.SimpleDateFormat;
import java.util.List;

import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.DontValidate;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;

import util.HibernateUtil;

/**
 *
 * @author Jens Rosenberg
 */
public class ProjectDescriptionActionBean extends CatalogActionBean {
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM-yy");
    private String startTime;
    private Language language;
    private String lang;
    
    
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

        
    private ProjectDescription projectDescription;    
    
    @Secure(role = Role.MODERATOR)
    public Resolution add(){
        return new ForwardResolution("/projectDescription/edit.jsp");
    }
    
    public Resolution view(){
        return new ForwardResolution("/projectDescription/view.jsp");
    }
    
    @DefaultHandler
    @DontValidate
    public Resolution list(){
        return new ForwardResolution("/projectDescription/list.jsp");
    }
    
    public Resolution categories(){
        return new ForwardResolution("/projectDescription/categories.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution edit(){
        if( getProjectDescription()!= null && getProjectDescription().getStartdate() != null){
            setStartTime(getSdf().format(getProjectDescription().getStartdate()));
        }        
        return new ForwardResolution("/projectDescription/edit.jsp");
    }
    
    @Secure(role = Role.MODERATOR)
    public Resolution delete(){
        getSession().delete(getProjectDescription());
        return new ForwardResolution("/projectDescription/deleted.jsp");
    }

    @Secure(role = Role.MODERATOR)
    public Resolution save(){
         try {
            getProjectDescription().setStartdate(getSdf().parse(this.getStartTime()));
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        getSession().saveOrUpdate(getProjectDescription());
        return new ForwardResolution("/projectDescription/view.jsp");
    }
    
    public List<Category> getCategoryList() {
        List<Category> list = getSession().createCriteria(Category.class).list();
        return list;
    }
    
    private Category category;
    private String sortBy;
    
    public List<ProjectDescription> getProjectDescriptions(){        
        Criteria crit = getSession().createCriteria(ProjectDescription.class);
        if (getCategory() != null){
            crit.add(Expression.eq("category", getCategory()));
        }
        if (getSortBy() != null){
            crit.addOrder(Order.desc(getSortBy()));
        }
        List list = crit.list();
        return list;
    }

    public void setProjectDescription(ProjectDescription projectDescription) {
        this.projectDescription = projectDescription;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public ProjectDescription getProjectDescription() {
        return projectDescription;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public SimpleDateFormat getSdf() {
        return sdf;
    }

    public void setSdf(SimpleDateFormat sdf) {
        this.sdf = sdf;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }
    
}
