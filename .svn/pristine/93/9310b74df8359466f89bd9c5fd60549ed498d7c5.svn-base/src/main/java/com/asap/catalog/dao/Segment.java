package com.asap.catalog.dao;

import org.hibernate.annotations.Type;

import javax.persistence.*;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * Created by IntelliJ IDEA.
 * User: mortenandersen
 * Date: 2007-02-20
 * Time: 07:43:10
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(name = "segment")


public class Segment {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    String tabName;

    @Type(type="text")
    String xml;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTabName() {
        return tabName;
    }

    public void setTabName(String tabName) {
        this.tabName = tabName;
    }

    public String getXml() {
        return xml;
    }

    public void setXml(String xml) {
        this.xml = xml;
    }

    public void addPageToXML(Page page){
        XStream xstream = new XStream(new DomDriver());
        xstream.alias("page", Page.class);
        String xml = xstream.toXML(page);
        System.out.println(xml);
    }

    public static void main(String[] args){
        Segment segment = new Segment();
        Page page = new Page();
        page.setTitle("PageTitle æøå");
        Page child = new Page();
        child.setTitle("Child");
        Page gchild = new Page();
        gchild.setTitle("gChild");
        child.addPage(gchild);
        page.addPage(child);
        segment.addPageToXML(page);
    }
        

}
