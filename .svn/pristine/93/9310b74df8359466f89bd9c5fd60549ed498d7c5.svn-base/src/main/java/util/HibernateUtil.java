package util;

import com.asap.catalog.dao.Component; 
import java.util.Collection;
import java.util.Set;
import java.util.Vector;
import javax.naming.spi.ResolveResult;
import javax.persistence.Entity;
import net.sourceforge.stripes.util.ResolverUtil;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {

    private static final SessionFactory sessionFactory;

    static {
        try {
            long time = System.currentTimeMillis();
           // System.out.println("Creating AnnotationConfiguration...");
            // Create the SessionFactory from hibernate.cfg.xml
            AnnotationConfiguration aConf = new AnnotationConfiguration();
            aConf.configure();
            long time2 = System.currentTimeMillis();
           // System.out.println("Finished creating annotationConf - time "+ (time2-time));
            
            ResolverUtil<Component> resolver = new ResolverUtil<Component>();
            /*ResolverUtil<Object> resolver = new ResolverUtil<Object>();
            resolver.findAnnotated(Entity.class);
            Set<Class<? extends Object>> components = resolver.getClasses();
           */
            Collection<String> packages = new Vector();
            packages.add("WEB-INF/classes");
            resolver.setLocationFilters(packages);
            resolver.loadImplementationsFromContextClassloader(Component.class);
            
            
            Set<Class<? extends Component>> components = resolver.getClasses();
            for(Class component : components){
                try{
                    aConf.addAnnotatedClass(component);
                    System.out.println("Added Component = "+component.getName());
                }
                catch(Exception e){
                    e.printStackTrace();
                }
            }
            long time3 = System.currentTimeMillis();
           // System.out.println("Finished adding components time = "+ (time3-time2) );
            sessionFactory = aConf.buildSessionFactory();
          //  System.out.println("Building Session factory takes = "+ (System.currentTimeMillis()-time3) );
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            ex.printStackTrace();
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}